package com.cst2335.android_final_project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * A CarDatabase class the inherits from SQLiteOpenHelper
 * which will create a data base to store the saved cars info
 */

public class CarDataBase extends SQLiteOpenHelper {

    /**'
     * creating static variables for the column names
     */

    protected final static String DATABASE_NAME = "CarDB";
    protected final static int VERSION_NUM = 2;
    public final static String TABLE_NAME = "CarInfo";
    public final static String COL_ID = "_id";
    public final static String COL_MAKE_ID = "MakeID";
    public final static String COL_MAKE_NAME = "MakeName";
    public final static String COL_MODEL_ID = "ModelID";
    public final static String COL_MODEL_NAME = "ModelName";


    /**
     * A super constructor in SQLiteOpenerHelper
     * @param ctx the Activity where the database is being opened.
     */

    public CarDataBase(Context ctx)
    {
        super(ctx, DATABASE_NAME, null, VERSION_NUM);
    }

    /**
     * onCreate method gets called when it is the first time to access
     *  the car database as it will create the database for the first time
     * @param db
     */

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_NAME + " (_id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_MAKE_ID +" text,"
                + COL_MAKE_NAME + " text,"
                + COL_MODEL_ID + " text,"
                + COL_MODEL_NAME  + " text);");
    }


    /**
     * onUpgrade method get called when the database does exist on the device,
     * and the version in the constructor is newer than the version that exists on the device
     * @param db
     * @param oldVersion
     * @param newVersion
     */

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL( "DROP TABLE IF EXISTS " + TABLE_NAME);

        onCreate(db);
    }

}
 /*public List<Car> favCars() {

        db = this.getWritableDatabase();
        List<Car> favCar = new ArrayList<>();
        Cursor results = db.query(TABLE_NAME, columns, null, null, null, null, null);
        results.moveToFirst();
        while (!results.isAfterLast()) {
            favCar.add(new Car(results.getLong(0),results.getString(1), results.getString(2), results.getString(3), results.getString(4)));
            results.moveToNext();
        }
        return favCar;
    }*/

//String [] columns = {CarDataBase.COL_ID, CarDataBase.COL_MAKE_ID, CarDataBase.COL_MAKE_NAME,CarDataBase.COL_MODEL_NAME,CarDataBase.COL_MODEL_ID};

//CarDataBase dbOpener= new CarDataBase(this);
//SQLiteDatabase db ;