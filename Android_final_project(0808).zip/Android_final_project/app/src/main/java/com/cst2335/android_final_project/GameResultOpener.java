package com.cst2335.android_final_project;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Game result database opener that stores the trivia result and the game setting information
 * Inheriting a helper class to manage database creation and version management
 */
public class GameResultOpener extends SQLiteOpenHelper {
    // just need to change first two variables (increment version number when change database table
    protected final static String DATABASE_NAME = "triviaDB";
    protected final static int VERSION_NUM = 5;
    public final static String TABLE_NAME = "GameResult";
    public final static String COL_ID = "_id";
    public final static String COL_NAME = "NAME";
    public final static String COL_DIFFICULTY = "DIFFICULTY";
    public final static String COL_SCORE = "SCORE";
    public final static String COL_AMOUNT = "AMOUNT";
    public final static String COL_TYPE = "TYPE";

    /**
     * Opener constructor
     * @param ctx database object to create and manage database
     */
    public GameResultOpener(Context ctx)
    {
        super(ctx, DATABASE_NAME, null, VERSION_NUM);
    }


    /**
     * onCreate method gets called if no database file exists
     * @param db database
     */
    @Override
    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL("CREATE TABLE " + TABLE_NAME + " (_id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_NAME + " TEXT,"
                + COL_DIFFICULTY + " TEXT,"
                + COL_SCORE + " TEXT,"
                + COL_AMOUNT + " TEXT,"
                + COL_TYPE  + " TEXT);");
    }


    /**
     * onUpgrade method is called if the database version is lower than the new version number
     * @param db database
     * @param oldVersion old version number
     * @param newVersion new version number
     */
    //this function gets called if the database version on your device is lower than VERSION_NUM
    //increment version number
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {   //Drop the old table:
        db.execSQL( "DROP TABLE IF EXISTS " + TABLE_NAME);

        //Create the new table:
        onCreate(db);
    }

    /**
     * onDowngrade method is called if the database version is higher than the new version number
     * @param db database
     * @param oldVersion old version number
     * @param newVersion new version number
     */
    //this function gets called if the database version on your device is higher than VERSION_NUM
    //decrement version number
    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {   //Drop the old table:
        db.execSQL( "DROP TABLE IF EXISTS " + TABLE_NAME);

        //Create the new table:
        onCreate(db);
    }
}
