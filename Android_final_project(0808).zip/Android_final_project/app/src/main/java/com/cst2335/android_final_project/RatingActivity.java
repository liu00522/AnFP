package com.cst2335.android_final_project;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class RatingActivity extends AppCompatActivity {

    private RatingBar ratingBar;
    private Button btn;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.ratingr_layout);


        ratingBar = findViewById(R.id.rating_bar);
        btn = findViewById(R.id.submit);

        SharedPreferences prefs = getSharedPreferences("rating", Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = prefs.edit();


        int rating = (int) prefs.getFloat("rating", 0);
        ratingBar.setRating(rating);


        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s = String.valueOf(ratingBar.getRating());
                Toast.makeText(getApplicationContext(), s + "star", Toast.LENGTH_SHORT).show();
                float rating = ratingBar.getRating();
                edit.putFloat("rating", rating);

                edit.commit();
            }
        });

    }
}
