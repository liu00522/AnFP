package com.cst2335.android_final_project;

/**
 *A car class to create car objects
 */

public class Car {

    private String carMake;
    private String makeID;
    private String carName;
    private String nameID;
    private long dbID;

    /**
     * A car constructor to create car objects
     * based on the make , make ID , model name and mode ID
     * @param makeID
     * @param carMake
     * @param carName
     * @param nameID
     */

    public Car( String makeID,String carMake, String carName, String nameID) {

        this.makeID = makeID;
        this.carMake = carMake;
        this.carName = carName;
        this.nameID = nameID;

    }

    /**
     *A car constructor to create car objects for the data base
     *  based on the make , make ID , model name ,mode ID and data base ID
     * @param dbID
     * @param makeID
     * @param carMake
     * @param carName
     * @param nameID
     */

    public Car(long dbID, String makeID,String carMake, String carName, String nameID) {

        this.dbID = dbID;
        this.makeID = makeID;
        this.carMake = carMake;
        this.carName = carName;
        this.nameID = nameID;

    }

    /**
     * A getter to get the name of the car make
     * @return
     */

    public String getCarMake() {
        return carMake;
    }

    /**
     *  A getter to get the ID of the car make
     * @return
     */

    public String getMakeID() {
        return makeID;
    }

    /**
     *  A getter to get the name of the car model
     * @return
     */

    public String getCarName() {
        return carName;
    }

    /**
     *  A getter to get the ID of the car model
     * @return
     */

    public String getNameID() {
        return nameID;
    }

    /**
     *  A getter to get the database ID of a car row
     * @return
     */

    public long getDbID() {
        return dbID;
    }

    /**
     * A setter to set the name of the car make
     * @param carMake
     */


    public void setCarMake(String carMake) {
        this.carMake = carMake;
    }

    /**
     * A setter to set the ID of the car make
     * @param makeID
     */

    public void setMakeID(String makeID) {
        this.makeID = makeID;
    }

    /**
     * A setter to set the name of the car model
     * @param carName
     */

    public void setCarName(String carName) {
        this.carName = carName;
    }

    /**
     * A setter to set the ID of a car model
     * @param nameID
     */

    public void setNameID(String nameID) {
        this.nameID = nameID;
    }

    /**
     * A setter to set the database ID of a car row
     * @param dbID
     */

    public void setDbID(long dbID) {
        this.dbID = dbID;
    }
}
