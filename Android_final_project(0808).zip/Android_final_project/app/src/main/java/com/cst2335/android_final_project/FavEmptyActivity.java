package com.cst2335.android_final_project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;

public class FavEmptyActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fav_empty);
        Bundle fragmentData = getIntent().getExtras();

        FavDetailsFragment newFragment = new FavDetailsFragment();

        newFragment.setArguments(fragmentData);

        FragmentManager fm = getSupportFragmentManager();

        fm.beginTransaction().replace(R.id.favFrame,newFragment).addToBackStack("AnyName").commit();

    }
}