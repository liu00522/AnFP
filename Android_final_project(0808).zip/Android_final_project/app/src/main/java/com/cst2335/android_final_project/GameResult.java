package com.cst2335.android_final_project;

/**
 * GameResult class to hold each object's result information
 */
public class GameResult {

    private long id;
    private String name;
    private String difficulty;
    private String score;
    private String amount;
    private String type;

    /**
     * GameResult constructor used when create a new object
     * @param id user id
     * @param name player name
     * @param difficulty level of difficulty
     * @param score final score
     * @param amount amount of questions
     * @param type type of quiz
     */
    public GameResult(long id, String name, String difficulty, String score, String amount, String type) {
        this.id = id;
        this.name = name;
        this.difficulty = difficulty;
        this.score = score;
        this.amount = amount;
        this.type = type;
    }

    /**
     * A getter of ID
     * @return returns id
     */
    public long getId() {
        return id;
    }

    /**
     * A setter of ID
     * @param id id
     */
    public void setId(long id) {
        this.id = id;
    }

    /**
     *  A getter of user name
     * @return returns user name
     */
    public String getName() {
        return name;
    }

    /**
     * A setter of user name
     * @param name user name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * A getter of game difficulty
     * @return returns the difficulty
     */
    public String getDifficulty() {
        return difficulty;
    }

    /**
     * A setter of game difficulty
     * @param difficulty level of difficulty
     */
    public void setDifficulty(String difficulty) {
        this.difficulty = difficulty;
    }

    /**
     * A getter of final score
     * @return returns the final score
     */
    public String getScore() {
        return score;
    }

    /**
     * A setter of final score
     * @param score final score
     */
    public void setScore(String score) {
        this.score = score;
    }

    /**
     * A getter of amount of questions
     * @return returns the amount of questions
     */
    public String getAmount() {
        return amount;
    }

    /**
     * A setter of the amount of questions
     * @param amount the amount of questions
     */
    public void setAmount(String amount) {
        this.amount = amount;
    }

    /**
     * A getter of type of game
     * @return returns the type of game
     */
    public String getType() {
        return type;
    }

    /**
     * A setter of the type of game
     * @param type the type of game
     */
    public void setType(String type) {
        this.type = type;
    }
}
