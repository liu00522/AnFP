package com.cst2335.android_final_project;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;

/**
 * A public class that inherits from AppCompatActivity super class
 * and it includes baseAdapter class
 */

public class favListView extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    /**
     * Variables declared to be used throughout the favListView class
     */

    private static ArrayList<Car> favorites;
    private SQLiteDatabase db;
    private FavListAdapter myAdapter;

    /**
     * An onCreate function which gets called when the program starts
     *
     * @param savedInstanceState
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fav_list_view);

        /**
         * initializing the declared variables
         */

        favorites = new ArrayList<>();
        myAdapter = new FavListAdapter();

        /**
         * creating a SQLite object to create a writable database
         */

        CarDataBase dbopener = new CarDataBase(this);
        db = dbopener.getWritableDatabase();

        ListView favList = findViewById(R.id.favList);
        favList.setAdapter(myAdapter);

        loadDataFromDB();

        /**
         *  Creating a cursor to loop through the database rows to get data
         */


        /**
         * Using getColumnIndex to get the indices of the database columns
         */


        /**
         * A loop using the cursor to extract the saved car info from the database
         */


        // When clicking on a car in list it will show the name of the car in fragment

        /**
         * A click listener that will be invoked when an item on the list
         * tha will open a fragment to show the car's info
         * and send the info through a bundle to the fragment activity
         */

        favList.setOnItemClickListener((list, item, position, id) -> {

            Bundle dataToPass = new Bundle();
            dataToPass.putLong(CarDataBase.COL_ID, id);
            dataToPass.putString(CarDataBase.COL_MAKE_ID, favorites.get(position).getMakeID());
            dataToPass.putString(CarDataBase.COL_MAKE_NAME, favorites.get(position).getCarMake());
            dataToPass.putString(CarDataBase.COL_MODEL_ID, favorites.get(position).getNameID());
            dataToPass.putString(CarDataBase.COL_MODEL_NAME, favorites.get(position).getCarName());


            boolean isTablet = findViewById(R.id.favFrame) != null;

            /**
             * An if condition to decide is it a tablet or a phone for the fragment
             */

            if (isTablet) {
                FavDetailsFragment dFragment = new FavDetailsFragment(); //add a DetailFragment
                dFragment.setArguments(dataToPass); //pass it a bundle for information
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.favFrame, dFragment) //Add the fragment in FrameLayout
                        .commit(); //actually load the fragment. Calls onCreate() in DetailFragment
            } else //isPhone
            {
                Intent nextActivity = new Intent(this, FavEmptyActivity.class);
                nextActivity.putExtras(dataToPass); //send data to next activity
                startActivity(nextActivity); //make the transition
            }
        });

        androidx.appcompat.widget.Toolbar tBar = (Toolbar) findViewById(R.id.toolbar);

        //This loads the toolbar, which calls onCreateOptionsMenu below:
        setSupportActionBar(tBar);

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this,
                drawer, tBar, R.string.open, R.string.close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

    }

    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu items for use in the action bar
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.apptoolbar, menu);
        return true;
    }

    /*Intent goToTrivia = new Intent(this,TriviaActivity.class);
    Intent goToSongstar = new Intent(this,SongsterActivity.class);
    Intent goToCar = new Intent(this,CarListView.class);
    Intent goToActivity;*/

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        View listLayout = findViewById(R.id.favListLayout);
        String message = null;
        //Look at your menu XML file. Put a case for every id in that file:
        switch (item.getItemId()) {
            //what to do when the menu item is selected:
            case R.id.trivia:
                //goToActivity = goToTrivia;
                message = getResources().getString(R.string.leaveToTrivia);
                ;
                break;
            case R.id.songster:
                // goToActivity = goToSongstar;
                message = getResources().getString(R.string.leaveToSongster);
                break;
            case R.id.Car:
                // goToActivity = goToCar;
                message = "You clicked on item 3";
                break;
            case R.id.soccer:
                Intent goToSoccer = new Intent(favListView.this, SoccerActivity.class);
                startActivity(goToSoccer);
                message = getResources().getString(R.string.leaveToSoccer);
                break;
        }
        Snackbar snackbar = Snackbar
                .make(listLayout, message, Snackbar.LENGTH_LONG);
        snackbar.show();
        // startActivity(goToActivity);
        return true;
    }

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.help) {
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
            alertDialogBuilder.setTitle(getResources().getString(R.string.Alert_Title))
                    .setMessage(getResources().getString(R.string.Alert_dialog))
                    .create().show();
        } else if (id == R.id.backCarSerach) {
            Intent goToCarSearch = new Intent(favListView.this, CarListView.class);
            startActivity(goToCarSearch);
        } else if (id == R.id.finish) {
            Intent goToFavourites = new Intent(this, favListView.class);
            startActivity(goToFavourites);
            finish();
        }

        View listLayout = findViewById(R.id.favListLayout);
        String message = null;
        //Look at your menu XML file. Put a case for every id in that file:
        switch (item.getItemId()) {
            //what to do when the menu item is selected:
            case R.id.trivia:
                //goToActivity = goToTrivia;
                message = getResources().getString(R.string.leaveToTrivia);
                ;
                break;
            case R.id.songster:
                // goToActivity = goToSongstar;
                message = getResources().getString(R.string.leaveToSongster);
                break;
            case R.id.Car:
                // goToActivity = goToCar;
                message = "You clicked on item 3";
                break;
            case R.id.soccer:
                Intent goToSoccer = new Intent(favListView.this, SoccerActivity.class);
                startActivity(goToSoccer);
                message = getResources().getString(R.string.leaveToSoccer);
                break;
        }

        Snackbar snackbar = Snackbar
                .make(listLayout, message, Snackbar.LENGTH_LONG);
        snackbar.show();
        DrawerLayout drawerLayout = findViewById(R.id.drawer_layout);
        drawerLayout.closeDrawer(GravityCompat.START);


        return true;
    }


    /**
     * A FavListAdapter class which inherits from the BaseAdapter super class
     * that class implements four methods
     * getCount, getItem, getItemId,getView
     */

    class FavListAdapter extends BaseAdapter {

        /**
         * A getCount methods which return the size of the list
         *
         * @return size of the list
         */

        @Override
        public int getCount() {
            return favorites.size();
        }

        /**
         * A getItem method which returns a number
         * that represents the position of the item that was clicked
         *
         * @param position
         * @return the position of the item o the list
         */

        @Override
        public Car getItem(int position) {
            return favorites.get(position);
        }

        /**
         * A getItemId method which returns the database id
         * of the selected item on the list
         *
         * @param position
         * @return returns long which represent the database id
         * of the selected item on the list
         */

        @Override
        public long getItemId(int position) {
            return favorites.get(position).getDbID();
        }

        /**
         * A getView method which makes the rows in the list customizable
         *
         * @param position
         * @param convertView
         * @param parent
         * @return rowView
         */

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            LayoutInflater inflater = getLayoutInflater();
            View rowView = inflater.inflate(R.layout.fav_row, parent, false);
            TextView carRow = rowView.findViewById(R.id.savedCar);
            carRow.setText(getResources().getString(R.string.carNameRow) + getItem(position).getCarName());


            return rowView;
        }

    }

    /**
     *
     */

    @Override
    protected void onResume() {

        super.onResume();
        loadDataFromDB();
    }

    @Override
    protected void onPause() {

        super.onPause();
    }

    /**
     * A helper method that will be called when the delete button is clicked
     *
     * @param id
     */

    public void deleteCar(long id) {

        db.delete(CarDataBase.TABLE_NAME, CarDataBase.COL_ID + "= " + id, null);
        Toast.makeText(this, getResources().getString(R.string.carDeleted), Toast.LENGTH_LONG).show();
        myAdapter.notifyDataSetChanged();
    }

    /**
     *
     */

    public void loadDataFromDB() {

        favorites.clear();

        String[] columns = {CarDataBase.COL_ID, CarDataBase.COL_MAKE_ID, CarDataBase.COL_MAKE_NAME, CarDataBase.COL_MODEL_NAME, CarDataBase.COL_MODEL_ID};
        Cursor results = db.query(CarDataBase.TABLE_NAME, columns, null, null, null, null, null);

        int idColIndex = results.getColumnIndex(CarDataBase.COL_ID);
        int makeColInd = results.getColumnIndex(CarDataBase.COL_MAKE_NAME);
        int makeIDColInd = results.getColumnIndex(CarDataBase.COL_MAKE_ID);
        int modelColInd = results.getColumnIndex(CarDataBase.COL_MODEL_NAME);
        int modelIDColInd = results.getColumnIndex(CarDataBase.COL_MODEL_ID);

        results.moveToFirst();
        while (!results.isAfterLast()) {
            long id = results.getLong(idColIndex);
            String carMake = results.getString(makeColInd);
            String makeID = results.getString(makeIDColInd);
            String modelName = results.getString(modelColInd);
            String modelID = results.getString(modelIDColInd);
            favorites.add(new Car(id, carMake, makeID, modelName, modelID));
            results.moveToNext();
        }
        myAdapter.notifyDataSetChanged();
    }


}

 /*results.moveToFirst();
        while (!results.isAfterLast()) {
            favorites.add(new Car(results.getLong(0),results.getString(1), results.getString(2), results.getString(3), results.getString(4)));
            results.moveToNext();
        }*/

/*Button deleteFromDB = rowView.findViewById(R.id.delete);

            deleteFromDB.setOnClickListener(d -> {
                deleteCar(favorites.get(position).getDbID());
                favorites.remove(position);

            });*/