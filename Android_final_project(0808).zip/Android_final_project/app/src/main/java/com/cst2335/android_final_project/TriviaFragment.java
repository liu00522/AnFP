package com.cst2335.android_final_project;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

/**
 * TriviaFragment which retrieves bundle data from TriviaScoreActivity
 * and display data in fragment page
 */
public class TriviaFragment extends Fragment {

    private Bundle dataFromActivity;
    private long id;
    private String name, difficulty, score, amount, type;
    private AppCompatActivity parentActivity;

    /**
     * This is for inflating the page
     * @param inflater inflater
     * @param container container
     * @param savedInstanceState bundle savedInstanceState
     * @return
     */
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // retrieve bundle from TriviaScoreActivity
        dataFromActivity = getArguments();
        id = dataFromActivity.getLong(TriviaScoreActivity.ITEM_ID);
        name = dataFromActivity.getString(TriviaScoreActivity.ITEM_NAME);
        difficulty = dataFromActivity.getString(TriviaScoreActivity.ITEM_DIFFICULTY);
        score = dataFromActivity.getString(TriviaScoreActivity.ITEM_SCORE);
        amount = dataFromActivity.getString(TriviaScoreActivity.ITEM_AMOUNT);
        type = dataFromActivity.getString(TriviaScoreActivity.ITEM_TYPE);

        // Inflate the layout for this fragment
        View result = inflater.inflate(R.layout.trivia_fragment, container, false);

        //show the id:
        TextView idView = (TextView)result.findViewById(R.id.userid);
        idView.setText(getResources().getString( R.string.userid) + " " + String.valueOf(id));

        //show the name
        TextView nameView = (TextView)result.findViewById(R.id.name);
        nameView.setText(getResources().getString( R.string.name) + " " + name);

        //show the difficulty
        TextView diffView = (TextView)result.findViewById(R.id.difficulty);
        diffView.setText(getResources().getString( R.string.diff) + " " + difficulty);

        //show the score
        TextView scoreView = (TextView)result.findViewById(R.id.score);
        scoreView.setText(getResources().getString( R.string.score) + " " + score);

        //show the amount
        TextView amountView = (TextView)result.findViewById(R.id.amount);
        amountView.setText(getResources().getString( R.string.amount) + " " + amount);

        //show the type
        TextView typeView = (TextView)result.findViewById(R.id.type);
        typeView.setText(getResources().getString( R.string.type) + " " + type);

        // get the delete button, and add a click listener:
        Button finishButton = (Button)result.findViewById(R.id.returnBtn);
        finishButton.setOnClickListener( clk -> {

            //Tell the parent activity to remove
            parentActivity.getSupportFragmentManager().beginTransaction().remove(this).commit();
        });

        return result;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);

        //context will either be FragmentExample for a tablet, or EmptyActivity for phone
        parentActivity = (AppCompatActivity)context;
    }
}
