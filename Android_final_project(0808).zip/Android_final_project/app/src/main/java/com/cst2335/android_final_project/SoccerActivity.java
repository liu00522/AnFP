package com.cst2335.android_final_project;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Switch;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

public class SoccerActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private ListView soccerListview;
    private ArrayList<SoccerMessage> msgList = new ArrayList<>();
    private SoccerAdapter soccerAdapter = new SoccerAdapter();

    private String readerDate;
    private SQLiteDatabase db;
    private String readerTitle;
    private Bitmap readerthumbImage;
    private SharedPreferences prefs = null;
    private String readerImgUrl;
    private String link;
    private String desc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_soccer);


        TextView textVW = findViewById(R.id.readerDesc);
        soccerListview = findViewById(R.id.soccerListview);
        soccerListview.setAdapter(soccerAdapter);


        SoccerQuery query = new SoccerQuery();
        query.execute("https://www.goal.com/feeds/en/news?fmt=rss");

        // article views
        ImageView readerImgVw = findViewById(R.id.readerImg);
        TextView readerDateVw = findViewById(R.id.readerDate);
        TextView readerDescVw = findViewById(R.id.readerDesc);
        TextView readerUrlVw = findViewById(R.id.readerURL);
        TextView readerTitleVw = findViewById(R.id.soccerNewsTitle);
        Button openInBrow = findViewById(R.id.openInBrowswer);
        Button myFav = findViewById(R.id.myFav);
        Button saveToFav = findViewById(R.id.saveToFav);

        //  reader view
        soccerListview.setOnItemClickListener((parent, view, position, id) -> {
            readerDateVw.setText(soccerAdapter.getItem(position).getDate());
            readerDescVw.setText(soccerAdapter.getItem(position).getDescription());
            readerImgVw.setImageBitmap(soccerAdapter.getItem(position).getThumbImage());
            readerUrlVw.setText(soccerAdapter.getItem(position).getLink());

            // getting items for db
            readerDate = soccerAdapter.getItem(position).getDate();
            readerTitle = soccerAdapter.getItem(position).getTitle();
            readerthumbImage = soccerAdapter.getItem(position).getThumbImage();
            readerImgUrl = soccerAdapter.getItem(position).getImgURL();
            link = soccerAdapter.getItem(position).getLink();
            desc = soccerAdapter.getItem(position).getDescription();

        });


        //  open in browser button
        openInBrow.setOnClickListener(click -> {
            String s = readerUrlVw.getText().toString();
            Uri uri = Uri.parse(s);
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            startActivity(intent);
        });

        //  comment box
        EditText commentTx = findViewById(R.id.soccerEditTx);
        prefs = getSharedPreferences("lastSearch", Context.MODE_PRIVATE);
        String commentString = prefs.getString("How many did I read last time?", " ");
        commentTx.setText(commentString);

        //  my fav
        Intent goToFav = new Intent(SoccerActivity.this, SoccerFavourite.class);
        myFav.setOnClickListener(click -> {
            startActivity(goToFav);
        });


        // save to fav
        saveToFav.setOnClickListener(checked -> {
            addToFavDB(readerTitle, readerDate, link, desc, readerImgUrl);
            saveSharedPrefs(commentTx.getText().toString());
            Snackbar.make(saveToFav, "save to favrourite!", Snackbar.LENGTH_SHORT).show();

        });


        /**
         * This gets the toolbar from the layout:
         */

        androidx.appcompat.widget.Toolbar tBar = (Toolbar) findViewById(R.id.toolbar);

        /**
         * This loads the toolbar, which calls onCreateOptionsMenu below:
         */
        setSupportActionBar(tBar);


        /**
         * this finds the DrawerLayout by id
         * and make it visible when the user
         */

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this,
                drawer, tBar, R.string.open, R.string.close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        View listLayout = findViewById(R.id.activity_soccer);
        String message = null;
        //Look at your menu XML file. Put a case for every id in that file:
        switch (item.getItemId()) {
            //what to do when the menu item is selected:
            case R.id.trivia:
                //goToActivity = goToTrivia;
                message = getResources().getString(R.string.leaveToTrivia);
                break;
            case R.id.songster:
                // goToActivity = goToSongstar;
                message = getResources().getString(R.string.leaveToSongster);
                break;
            case R.id.Car:
                // goToActivity = goToCar;
                Intent goToCar = new Intent(this, CarListView.class);
                startActivity(goToCar);
                message = "You clicked on item 3";
                break;
            case R.id.soccer:
                //  goToActivity = goToSoccer;
                message = getResources().getString(R.string.leaveToSoccer);
                break;
        }
        Snackbar snackbar = Snackbar
                .make(listLayout, message, Snackbar.LENGTH_LONG);
        snackbar.show();
        /*Snackbar.make(, message, BaseTransientBottomBar.LENGTH_LONG)
                .show();*/
        // startActivity(goToActivity);
        return true;
    }

    /**
     * A method that would take an item from the navigation bar
     * and makes this item clickable
     *
     * @param item
     * @return boolean
     */

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {

        int id = item.getItemId();

        /**
         * When the help item is clicked and alert dialog will
         * pop up with a title and a message
         */

        if (id == R.id.help) {
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
            alertDialogBuilder.setTitle(getResources().getString(R.string.Alert_Title))
                    .setMessage(getResources().getString(R.string.Alert_dialog))
                    .create().show();
            /**
             * When the favourites item is clicked and it will moves the user
             * to a list of the favourites were saved to the database
             * pop up with a title and a message
             */

        } else if (id == R.id.soccerFav) {
            Intent goToFavourites = new Intent(SoccerActivity.this, SoccerFavourite.class);
            startActivity(goToFavourites);


        } else {
//            Intent goToCarSearch = new Intent(this, CarListView.class);
//            startActivity(goToCarSearch);
            finish();
        }

        View listLayout = findViewById(R.id.activity_soccer);
        String message = null;
        //Look at your menu XML file. Put a case for every id in that file:
        switch (item.getItemId()) {
            //what to do when the menu item is selected:
            case R.id.trivia:
                //goToActivity = goToTrivia;
                message = getResources().getString(R.string.leaveToTrivia);
                break;
            case R.id.songster:
                // goToActivity = goToSongstar;
                message = getResources().getString(R.string.leaveToSongster);
                break;
            case R.id.Car:
                Intent goToCar = new Intent(this, CarListView.class);
                startActivity(goToCar);
                message = "Going to car activity";
                break;
            case R.id.soccer:
                //  goToActivity = goToSoccer;
                message = getResources().getString(R.string.leaveToSoccer);
                break;
        }

        Snackbar snackbar = Snackbar
                .make(listLayout, message, Snackbar.LENGTH_LONG);
        snackbar.show();

        DrawerLayout drawerLayout = findViewById(R.id.drawer_layout);
        drawerLayout.closeDrawer(GravityCompat.START);


        return true;
    }


    /**
     * A method gets called when the toolbar is loaded
     *
     * @param menu
     * @return boolean
     */

    public boolean onCreateOptionsMenu(Menu menu) {

        /**
         * Inflate the menu items for use in the action bar
         */

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.apptoolbar, menu);

        return true;
    }


    /**
     * A save Shared preferences method that would take
     * the text the user entered in the search and save in a Map
     *
     * @param stringToSave
     */

    private void saveSharedPrefs(String stringToSave) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("Comment", stringToSave);
        editor.commit();
    }

    //  query
    private class SoccerQuery extends AsyncTask<String, Integer, String> {

        private String title;
        private String date;
        private String link;
        private URL url = null;
        private Bitmap thumbNailImage;
        private String description;
        private String language;
        private String imgURL;

        @Override
        protected String doInBackground(String... args) {

            try {
                url = new URL(args[0]);
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                InputStream response = urlConnection.getInputStream();


                //  pull parser
                XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
                factory.setNamespaceAware(false);
                XmlPullParser xpp = factory.newPullParser();
                xpp.setInput(response, "UTF-8");


                int eventType = xpp.getEventType(); //The parser is currently at START_DOCUMENT


                while (eventType != XmlPullParser.END_DOCUMENT) {
                    if (eventType == XmlPullParser.START_TAG) {
                        if (xpp.getName().equals("title")) {
                            xpp.next();
                            title = xpp.getText();
                            publishProgress(25);
                        } else if (xpp.getName().equals("pubDate")) {
                            xpp.next();
                            date = xpp.getText();
                            publishProgress(50);
                        } else if (xpp.getName().equals("link")) {
                            xpp.next();
                            link = xpp.getText();
                        } else if (xpp.getName().equals("description")) {
                            xpp.next();
                            description = xpp.getText();
                        } else if
                        (xpp.getName().equals("media:thumbnail")) {
                            String url1 = xpp.getAttributeValue(null, "url");
                            imgURL = url1;
                            url = new URL(url1);
                            urlConnection = (HttpURLConnection) url.openConnection();
                            urlConnection.connect();
                            int responseCode = urlConnection.getResponseCode();
                            if (responseCode == 200) {
                                thumbNailImage = BitmapFactory.decodeStream(urlConnection.getInputStream());
                            }
                        } else if (xpp.getName().equals("dc:language")) {
                            xpp.next();
                            language = xpp.getText();
                            msgList.add(new SoccerMessage(0, title, date, link, thumbNailImage, description, imgURL));
                        }
                    }
                    eventType = xpp.next(); //move to the next xml event and store it in a variable
                }
                publishProgress(75);
            } catch (
                    Exception e) {
                e.printStackTrace();
            }
            return "Done";
        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            publishProgress(90);
        }

        @Override
        protected void onPostExecute(String fromDoInBackground) {
            //set the ListView
            soccerListview.setAdapter(soccerAdapter);

            //set the ProgressBar
//            pbSoccer.setVisibility(View.INVISIBLE);

            //set Snackbar
//            Snackbar.make(pbSoccer, R.string.soccer_list_snackbar, Snackbar.LENGTH_LONG).show();

        }
    }

    private class SoccerAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return msgList.size();
        }

        @Override
        public SoccerMessage getItem(int position) {
            return msgList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return (long) position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            //get a layout for this row at position
            LayoutInflater inflater = getLayoutInflater();
            View newView = inflater.inflate(R.layout.soccernews_layout, parent, false);
            TextView txtTitle = newView.findViewById(R.id.soccerNewsTitle);
            txtTitle.setText(getItem(position).getTitle());
            TextView txtDate = newView.findViewById(R.id.soccerNewsDate);
            txtDate.setText(getItem(position).getDate());
            ImageView thumbNailImg = newView.findViewById(R.id.thumbNailImage);
            thumbNailImg.setImageBitmap(getItem(position).getThumbImage());
            return newView;
        }

    }

    //  add to fav db
    private void addToFavDB(String title, String date, String link, String description, String imgURL) {
        SoccerOpener soccerOpener = new SoccerOpener(this);
        db = soccerOpener.getWritableDatabase();
        ContentValues newRowValues = new ContentValues();
        newRowValues.put(SoccerOpener.SOCCER_COL_TITLE, title);
        newRowValues.put(SoccerOpener.SOCCER_COL_DATE, date);
        newRowValues.put(SoccerOpener.SOCCER_COL_LINK, link);
        newRowValues.put(SoccerOpener.SOCCER_COL_DESC, description);
        newRowValues.put(SoccerOpener.SOCCER_COL_IMGURL, readerImgUrl);

        long insert = db.insert(SoccerOpener.TABLE_NAME, null, newRowValues);
    }


}
