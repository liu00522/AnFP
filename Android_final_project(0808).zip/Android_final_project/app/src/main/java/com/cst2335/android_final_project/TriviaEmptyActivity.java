package com.cst2335.android_final_project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.os.Bundle;

/**
 * TriviaEmptyActivity that embody the trivia fragment
 */
public class TriviaEmptyActivity extends AppCompatActivity {

    /**
     * The initially called method that get the passed data from TriviaScoreActivity
     * and pass the data to the fragment
     * @param savedInstanceState bundle savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trivia_empty);

        //get the data that was passed from TriviaScoreActivity
        Bundle dataToPass = getIntent().getExtras();

        TriviaFragment dFragment = new TriviaFragment();
        //pass data to the the fragment
        dFragment.setArguments( dataToPass );
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.triviaFrame, dFragment)
                .commit();
    }
}