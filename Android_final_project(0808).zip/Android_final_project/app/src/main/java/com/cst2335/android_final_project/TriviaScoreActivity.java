package com.cst2335.android_final_project;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;

/**
 * TriviaScoreActivity which is the logic of the score page of Trivia game
 * Retrieves player's game result, and display all previous scores on the ListView
 * Implemented toolbar and navigation bar let user to switch to other applications
 */
public class TriviaScoreActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private String name, difficulty, score, amount, type;
    MyListAdapter myAdapter;
    ArrayList<GameResult> gameResults = new ArrayList<>();
    private SQLiteDatabase scoreDB;
    private ListView resultList;

    // fragment instances
    public static final String ITEM_ID = "ID";
    public static final String ITEM_NAME = "NAME";
    public static final String ITEM_DIFFICULTY = "DIFFICULTY";
    public static final String ITEM_SCORE = "SCORE";
    public static final String ITEM_AMOUNT = "AMOUNT";
    public static final String ITEM_TYPE = "TYPE";

    /**
     * onCreate is the initial stage of the class
     * Retrieves player information from game activity and saves that in the database
     * Fragment shows details of each player's game information
     * @param savedInstanceState bundle savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score);

        // Field
        resultList = findViewById(R.id.resultListView);

        // Receive the object goToProfile from MainActivity
        Intent fromGame = getIntent();
        name = fromGame.getStringExtra("Name");
        difficulty = fromGame.getStringExtra("Difficulty");
        score = fromGame.getStringExtra("Score");
        amount = fromGame.getStringExtra("Amount");
        type = fromGame.getStringExtra("Type");

        loadDataFromDatabase(); //get any previously saved Message objects

        //add to the database and get the new ID
        ContentValues newRowValues = new ContentValues();

        //Now provide a value for every database column defined in Opener.java:
        //put string name in the text column:
        newRowValues.put(GameResultOpener.COL_NAME, name);
        newRowValues.put(GameResultOpener.COL_DIFFICULTY, difficulty);
        newRowValues.put(GameResultOpener.COL_SCORE, score);
        newRowValues.put(GameResultOpener.COL_SCORE, amount);
        newRowValues.put(GameResultOpener.COL_SCORE, type);

        //Now insert in the database:
        long newId = scoreDB.insert(GameResultOpener.TABLE_NAME, null, newRowValues);

        //now you have the newId, you can create the Contact object
        GameResult newResult = new GameResult(newId, name, difficulty, score, amount, type);

        //add the new message to the list:
        gameResults.add(newResult);


        // Create an adapter object and send it to the ListView
        myAdapter = new MyListAdapter();
        resultList.setAdapter(myAdapter);

        View listLayout = findViewById(R.id.activity_score);

        resultList.setOnItemLongClickListener((parent, view, pos, id) -> {
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
            alertDialogBuilder.setTitle("Do you want to delete this?")

                    //What is the message:
                    .setMessage("The selected row is: " + pos + "\nThe database ID is: " + id)

                    //what the Yes button does:
                    .setPositiveButton("Delete", (click, arg) -> {
                        long recordID = gameResults.get(pos).getId();
                        deleteResult(gameResults.get(pos));
                        gameResults.remove(pos);
                        myAdapter.notifyDataSetChanged();

                        String message = "ID" + recordID + " has successfully deleted.";
                        Snackbar snackbar = Snackbar
                                .make(listLayout, message, Snackbar.LENGTH_LONG);
                        snackbar.show();
                    })

                    //What the No button does:
                    .setNegativeButton("Cancel", (click, arg) -> {
                    })

                    //Show the dialog
                    .create().show();

            return true;
        });

        // Trivia Fragment
        resultList.setOnItemClickListener((list, item, position, id) -> {
            //Create a bundle to pass data to the new fragment
            Bundle dataToPass = new Bundle();

            dataToPass.putLong(ITEM_ID, gameResults.get(position).getId());
            dataToPass.putString(ITEM_NAME, gameResults.get(position).getName());
            dataToPass.putString(ITEM_DIFFICULTY, gameResults.get(position).getDifficulty());
            dataToPass.putString(ITEM_SCORE, gameResults.get(position).getScore());
            dataToPass.putString(ITEM_AMOUNT, gameResults.get(position).getAmount());
            dataToPass.putString(ITEM_TYPE, gameResults.get(position).getType());

            Intent nextActivity = new Intent(TriviaScoreActivity.this, TriviaEmptyActivity.class);
            nextActivity.putExtras(dataToPass); //send data to next activity
            startActivity(nextActivity); //make the transition
        });

        /**
         * This gets the toolbar from the layout:
         */

        androidx.appcompat.widget.Toolbar tBar = (Toolbar) findViewById(R.id.toolbar);

        /**
         * This loads the toolbar, which calls onCreateOptionsMenu below:
         */

        setSupportActionBar(tBar);

        /**
         * this finds the DrawerLayout by id
         * and make it visible when the user
         */

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this,
                drawer, tBar, R.string.open, R.string.close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    /**
     * A method gets called when the toolbar is loaded
     *
     * @param menu
     * @return boolean
     */
    public boolean onCreateOptionsMenu(Menu menu) {

        /**
         * Inflate the menu items for use in the action bar
         */

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.apptoolbar, menu);

        return true;
    }

    /**
     * Transfer to another activity when a Toolbar option selected
     * @param item
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        View listLayout = findViewById(R.id.activity_score);
        String message = null;
        //Look at your menu XML file. Put a case for every id in that file:
        switch (item.getItemId()) {
            //what to do when the menu item is selected:
            case R.id.trivia:
                Intent goToTrivia = new Intent(this, TriviaActivity.class);
                startActivity(goToTrivia);
                message = getResources().getString(R.string.leaveToTrivia);
                break;
            case R.id.songster:
                // goToActivity = goToSongstar;
//                message = getResources().getString(R.string.leaveToSongster);
                break;
            case R.id.Car:
                Intent goToCar = new Intent(this, CarListView.class);
                startActivity(goToCar);
                message = getResources().getString(R.string.leaveToCar);
                break;
            case R.id.soccer:
                Intent goToSoccer = new Intent(this, SoccerActivity.class);
                startActivity(goToSoccer);
                message = getResources().getString(R.string.leaveToSoccer);
                break;
        }
        Snackbar snackbar = Snackbar
                .make(listLayout, message, Snackbar.LENGTH_LONG);
        snackbar.show();

        return true;
    }

    /**
     * A method that would take an item from the navigation bar
     * and makes this item clickable
     *
     * @param item
     * @return boolean
     */
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {

        int id = item.getItemId();

        /**
         * When the help item is clicked and alert dialog will
         * pop up with a title and a message
         */
        if (id == R.id.helpTrivia) {
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
            alertDialogBuilder.setTitle(getResources().getString(R.string.Alert_Title))
                    .setMessage(getResources().getString(R.string.Alert_dialog_trivia))
                    .create().show();
            /**
             * When the favourites item is clicked and it will moves the user
             * to a list of the favourites were saved to the database
             * pop up with a title and a message
             */
        } else if (id == R.id.seeScore) {
            Intent goToScore = new Intent(TriviaScoreActivity.this, TriviaScoreActivity.class);
            startActivity(goToScore);

            /**
             * When the finish item is clicked the navigation bar will close
             * and go back to the car search activity
             *
             */
        } else if (id == R.id.finish) {
            Intent goToTrivia = new Intent(this, TriviaActivity.class);
            startActivity(goToTrivia);
            finish();
        }

        View listLayout = findViewById(R.id.activity_score);
        String message = null;
        //Look at your menu XML file. Put a case for every id in that file:
        switch (item.getItemId()) {
            //what to do when the menu item is selected:
            case R.id.trivia:
                Intent goToTrivia = new Intent(this, TriviaActivity.class);
                startActivity(goToTrivia);
                message = getResources().getString(R.string.leaveToTrivia);
                break;
            case R.id.songster:
                // goToActivity = goToSongstar;
//                message = getResources().getString(R.string.leaveToSongster);
                break;
            case R.id.Car:
                Intent goToCar = new Intent(this, CarListView.class);
                startActivity(goToCar);
                message = getResources().getString(R.string.leaveToCar);
                break;
            case R.id.soccer:
                Intent goToSoccer = new Intent(this, SoccerActivity.class);
                startActivity(goToSoccer);
                message = getResources().getString(R.string.leaveToSoccer);
                break;
        }

        Snackbar snackbar = Snackbar
                .make(listLayout, message, Snackbar.LENGTH_LONG);
        snackbar.show();

        DrawerLayout drawerLayout = findViewById(R.id.drawer_layout);
        drawerLayout.closeDrawer(GravityCompat.START);

        return true;
    }

    /**
     * Load data from the database to display all entries on the ListView
     */
    private void loadDataFromDatabase()
    {
        // database connection:
        GameResultOpener dbOpener = new GameResultOpener(this);
        scoreDB = dbOpener.getWritableDatabase(); //This calls onCreate() if you've never built the table before, or onUpgrade if the version here is newer

        // get all of the columns
        String[] columns = {GameResultOpener.COL_ID, GameResultOpener.COL_NAME, GameResultOpener.COL_DIFFICULTY, GameResultOpener.COL_SCORE, GameResultOpener.COL_AMOUNT, GameResultOpener.COL_TYPE};
        // query all the results from the database
        Cursor results = scoreDB.query(false, GameResultOpener.TABLE_NAME, columns, null, null, null, null, null, null);

        results.moveToPosition(-1);
        // Now the results object has rows of results that match the query.
        // find the column indices:
        int idColIndex = results.getColumnIndex(GameResultOpener.COL_ID);
        int nameColIndex = results.getColumnIndex(GameResultOpener.COL_NAME);
        int diffColIndex = results.getColumnIndex(GameResultOpener.COL_DIFFICULTY);
        int scoreColIndex = results.getColumnIndex((GameResultOpener.COL_SCORE));
        int amountColIndex = results.getColumnIndex((GameResultOpener.COL_AMOUNT));
        int typeColIndex = results.getColumnIndex((GameResultOpener.COL_TYPE));

        // iterate over the results, return true if there is a next item:
        while(results.moveToNext())
        {
            long id = results.getLong(idColIndex);
            String nameCol = results.getString(nameColIndex);
            String diffCol = results.getString(diffColIndex);
            String scoreCol = results.getString(scoreColIndex);
            String amountCol = results.getString(amountColIndex);
            String typeCol = results.getString(typeColIndex);

            // add the new GameResult to the array list:
            gameResults.add(new GameResult(id, nameCol, diffCol, scoreCol, amountCol, typeCol));
        }
    }

    /**
     * Delete one object of GameResult matches the id
     * @param gr an object of GameResult
     */
    protected void deleteResult(GameResult gr)
    {
        scoreDB.delete(GameResultOpener.TABLE_NAME, GameResultOpener.COL_ID + "= ?", new String[] {Long.toString(gr.getId())});
    }


    /**
     * MyListAdapter that inherits from BaseAdapter
     * Displays each row of instance from the list of game results
     */
    class MyListAdapter extends BaseAdapter {

        /**
         * A getter of the size of the list
         * @return returns size of the list
         */
        @Override   // returns number of items in the list
        public int getCount() {
            return gameResults.size();
        }

        /**
         * A getter of the object of gameResults
         * @param position position
         * @return returns the object of gameResults
         */
        @Override   // return the object that you want to display at row position in the list
        public Object getItem(int position) {
            return gameResults.get(position);
        }

        /**
         * A getter of the id of gameResults
         * @param position position
         * @return returns the id of gameResults
         */
        @Override   // returns the database id of the item at position i
        public long getItemId(int position) {
            return gameResults.get(position).getId();
        }

        /**
         * Creates a View object to go in a row of the ListView
         * @param position position
         * @param view view
         * @param viewGroup viewGroup (parent)
         * @return returns the new row
         */
        @Override
        public View getView(int position, View view, ViewGroup viewGroup) {
            LayoutInflater inflater = getLayoutInflater();
            View newRow = inflater.inflate(R.layout.layout_game_result, viewGroup, false);

            TextView thisRowID = newRow.findViewById(R.id.id);
            TextView thisRowName = newRow.findViewById(R.id.name);
            TextView thisRowScore = newRow.findViewById(R.id.score);
            TextView thisRowDiff = newRow.findViewById(R.id.difficulty);

            thisRowID.setText(" " + gameResults.get(position).getId());
            thisRowName.setText(" " + gameResults.get(position).getName());
            thisRowScore.setText(" " + gameResults.get(position).getScore());
            thisRowDiff.setText(" " + gameResults.get(position).getDifficulty());

            return newRow;
        }
    }
}