package com.cst2335.android_final_project;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;

/**
 * TriviaActivity which is the logic of the main page of Trivia game
 * Requires user input about game settings, directs a user to game page and/or score page
 * Implemented toolbar and navigation bar let user to switch to other applications
 */
public class TriviaActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{

    private Spinner spAmount, spType, spDiff;
    private static final String[] amounts = {"10", "20", "30", "40", "50"};
    private static final String[] types = {"True or False", "Multiple Choices"};
    private static final String[] difficulties = {"Easy", "Medium", "Hard"};
    private String amount, type, difficulty;
    private String message;

    /**
     * onCreate is the initial stage of the class
     * Creates spinners so that player can input the game settings
     * and buttons to start game and to see scores
     * @param savedInstanceState bundle savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trivia_main);

        // Field for spinners
        spAmount = findViewById(R.id.numOfQuestions);
        spType = findViewById(R.id.typeOfQuestions);
        spDiff = findViewById(R.id.levelOfDifficulty);

        // Adapters
        ArrayAdapter<String> adAmount = new ArrayAdapter<>(TriviaActivity.this,
                android.R.layout.simple_spinner_item, amounts);
        ArrayAdapter<String> adType = new ArrayAdapter<>(TriviaActivity.this,
                android.R.layout.simple_spinner_item, types);
        ArrayAdapter<String> adDiff = new ArrayAdapter<>(TriviaActivity.this,
                android.R.layout.simple_spinner_item, difficulties);

        adAmount.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adType.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        adDiff.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        spAmount.setAdapter(adAmount);
        spType.setAdapter(adType);
        spDiff.setAdapter(adDiff);

        spAmount.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            /**
             * Spinner selection for the amount of questions
             * @param parent parent
             * @param v view
             * @param position position
             * @param id id
             */
            @Override
            public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {
                switch (position) {
                    case 0:
                        amount = "10";
                        break;
                    case 1:
                        amount = "20";
                        break;
                    case 2:
                        amount = "30";
                        break;
                    case 3:
                        amount = "40";
                        break;
                    case 4:
                        amount = "50";
                        break;
                }
                message = amount + " Questions are selected";
                Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
            }

            /**
             * When Spinner is not selected
             * @param parent parent
             */
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                amount = "10";
            }
        });

        spType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            /**
             * Spinner selection for the type of questions
             * @param parent parent
             * @param v view
             * @param position position
             * @param id id
             */
            @Override
            public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {
                switch (position) {
                    case 0:
                        type = "boolean";
                        break;
                    case 1:
                        type = "multiple";
                        break;
                }
                message = type + " is selected";
                Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
            }
            /**
             * When Spinner is not selected
             * @param parent parent
             */
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                type = "boolean";
            }
        });

        spDiff.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            /**
             * Spinner selection for the level of difficulty
             * @param parent parent
             * @param v view
             * @param position position
             * @param id id
             */
            @Override
            public void onItemSelected(AdapterView<?> parent, View v, int position, long id) {
                switch (position) {
                    case 0:
                        difficulty = "easy";
                        break;
                    case 1:
                        difficulty = "medium";
                        break;
                    case 2:
                        difficulty = "hard";
                        break;
                }
                message = difficulty + " is selected";
                Toast.makeText(getApplicationContext(), message, Toast.LENGTH_LONG).show();
            }
            /**
             * When Spinner is not selected
             * @param parent parent
             */
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                difficulty = "easy";
            }
        });


        // Go to game page
        Intent goToGamePage = new Intent(TriviaActivity.this, TriviaGameActivity.class);
        Button gamePageBtn = findViewById(R.id.startBtn);

        gamePageBtn.setOnClickListener(btn -> {
            goToGamePage.putExtra("amount", amount);
            goToGamePage.putExtra("type", type);
            goToGamePage.putExtra("difficulty", difficulty);
            startActivity(goToGamePage);
        });

        // Go to score page
        Intent goToScorePage = new Intent(TriviaActivity.this, TriviaScoreActivity.class);
        Button scorePageBtn = findViewById(R.id.scoreBtn);

        scorePageBtn.setOnClickListener(btn -> {
            startActivity(goToScorePage);
        });

        /**
         * This gets the toolbar from the layout:
         */
        androidx.appcompat.widget.Toolbar tBar = (Toolbar) findViewById(R.id.toolbar);

        /**
         * This loads the toolbar, which calls onCreateOptionsMenu below:
         */
        setSupportActionBar(tBar);

        /**
         * this finds the DrawerLayout by id
         * and make it visible when the user
         */
        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this,
                drawer, tBar, R.string.open, R.string.close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    /**
     * A method gets called when the toolbar is loaded
     * @param menu
     * @return boolean
     */
    public boolean onCreateOptionsMenu(Menu menu) {

        /**
         * Inflate the menu items for use in the action bar
         */
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.apptoolbar, menu);

        return true;
    }

    /**
     * Transfer to another activity when a Toolbar option selected
     * @param item
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        View listLayout = findViewById(R.id.activity_trivia_main);
        String message = null;
        //Look at your menu XML file. Put a case for every id in that file:
        switch (item.getItemId()) {
            //what to do when the menu item is selected:
            case R.id.trivia:
                Intent goToTrivia = new Intent(this, TriviaActivity.class);
                startActivity(goToTrivia);
                message = getResources().getString(R.string.leaveToTrivia);
                break;
            case R.id.songster:
                // goToActivity = goToSongstar;
                message = getResources().getString(R.string.leaveToSongster);
                break;
            case R.id.Car:
                Intent goToCar = new Intent(this, CarListView.class);
                startActivity(goToCar);
                message = getResources().getString(R.string.leaveToCar);
                break;
            case R.id.soccer:
                Intent goToSoccer = new Intent(this, SoccerActivity.class);
                startActivity(goToSoccer);
                message = getResources().getString(R.string.leaveToSoccer);
                break;
        }
        Snackbar snackbar = Snackbar
                .make(listLayout, message, Snackbar.LENGTH_LONG);
        snackbar.show();

        return true;
    }

    /**
     * A method that would take an item from the navigation bar
     * and makes this item clickable
     * @param item
     * @return boolean
     */
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {

        int id = item.getItemId();

        /**
         * When the help item is clicked and alert dialog will
         * pop up with a title and a message
         */
        if (id == R.id.helpTrivia) {
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
            alertDialogBuilder.setTitle(getResources().getString(R.string.Alert_Title))
                    .setMessage(getResources().getString(R.string.Alert_dialog_trivia))
                    .create().show();
            /**
             * When the favourites item is clicked and it will moves the user
             * to a list of the favourites were saved to the database
             * pop up with a title and a message
             */
        } else if (id == R.id.seeScore) {
            Intent goToScore = new Intent(TriviaActivity.this, TriviaScoreActivity.class);
            startActivity(goToScore);

            /**
             * When the finish item is clicked the navigation bar will close
             * and go back to the car search activity
             *
             */
        } else if (id == R.id.finish) {
            Intent goToTrivia = new Intent(this, TriviaActivity.class);
            startActivity(goToTrivia);
            finish();
        }

        View listLayout = findViewById(R.id.activity_trivia_main);
        String message = null;
        //Look at your menu XML file. Put a case for every id in that file:
        switch (item.getItemId()) {
            //what to do when the menu item is selected:
            case R.id.trivia:
                Intent goToTrivia = new Intent(this, TriviaActivity.class);
                startActivity(goToTrivia);
                message = getResources().getString(R.string.leaveToTrivia);
                break;
            case R.id.songster:
//                Intent goToSongster = new Intent(this, song.class);
//                startActivity(goToSongster);
//                message = getResources().getString(R.string.leaveToSongster);
                break;
            case R.id.Car:
                Intent goToCar = new Intent(this, CarListView.class);
                startActivity(goToCar);
                message = getResources().getString(R.string.leaveToCar);
                break;
            case R.id.soccer:
                Intent goToSoccer = new Intent(this, SoccerActivity.class);
                startActivity(goToSoccer);
                message = getResources().getString(R.string.leaveToSoccer);
                break;
        }

        Snackbar snackbar = Snackbar
                .make(listLayout, message, Snackbar.LENGTH_LONG);
        snackbar.show();

        DrawerLayout drawerLayout = findViewById(R.id.drawer_layout);
        drawerLayout.closeDrawer(GravityCompat.START);

        return true;
    }
}