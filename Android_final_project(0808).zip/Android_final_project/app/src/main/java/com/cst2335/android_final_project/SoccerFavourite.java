package com.cst2335.android_final_project;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.squareup.picasso.Picasso;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class SoccerFavourite extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private ArrayList<SoccerMessage> soccerFavoriteList = new ArrayList<>();
    private SoccerFavAdapter favAdapter = new SoccerFavAdapter();
    //    private ProgressBar pbFSoccer;
    private ListView favList;
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_soccer_fav);

        TextView favDate = findViewById(R.id.favDate);
        favList = findViewById(R.id.soccerfavListview);
        loadFromDB();
        favList.setAdapter(favAdapter);

        //  finding views
        TextView favReaderDate = findViewById(R.id.favDate);
        TextView favURL = findViewById(R.id.favReaderURL);
        ImageView favReaderImg = findViewById(R.id.favReaderImg);
        TextView favDesc = findViewById(R.id.favReaderDesc);
        Button favOpenInBrow = findViewById(R.id.favOpenInBrowswer);


        /** fav list -> setting fav reader view
         *
         */
        favList.setOnItemClickListener((parent, view, position, id) -> {
            favReaderDate.setText(favAdapter.getItem(position).getDate());
            favURL.setText(favAdapter.getItem(position).getLink());
            favDesc.setText(favAdapter.getItem(position).getDescription());
            String favReaderImgURL = favAdapter.getItem(position).getImgURL();
            Picasso.get().load(favReaderImgURL).into(favReaderImg);

            // favOpenInBrow -> see detail in browser
            favOpenInBrow.setOnClickListener(click -> {
                String s = favURL.getText().toString();
                Uri uri = Uri.parse(s);
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            });

            // delete from db & fav list
            Button deleteFav = findViewById(R.id.deleteFav);
            deleteFav.setOnClickListener(click -> {
                SoccerMessage selectedMsg = soccerFavoriteList.get(position);
                deleteFromDB(selectedMsg.getTitle());
                favReaderDate.setText(null);
                favURL.setText(null);
                favDesc.setText(null);
                favReaderImg.setImageBitmap(null);
                soccerFavoriteList.remove(position);
                favAdapter.notifyDataSetChanged();
                Snackbar.make(deleteFav, "removed from favourite!", Snackbar.LENGTH_SHORT).show();
            });
        });


        /**
         * This gets the toolbar from the layout:
         */

        androidx.appcompat.widget.Toolbar tBar = (Toolbar) findViewById(R.id.toolbar);

        /**
         * This loads the toolbar, which calls onCreateOptionsMenu below:
         */
        setSupportActionBar(tBar);


        /**
         * this finds the DrawerLayout by id
         * and make it visible when the user
         */

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this,
                drawer, tBar, R.string.open, R.string.close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        View listLayout = findViewById(R.id.activityFav_soccer);
        String message = null;
        //Look at your menu XML file. Put a case for every id in that file:
        switch (item.getItemId()) {
            //what to do when the menu item is selected:
            case R.id.trivia:
                //goToActivity = goToTrivia;
                message = getResources().getString(R.string.leaveToTrivia);
                break;
            case R.id.songster:
                // goToActivity = goToSongstar;
                message = getResources().getString(R.string.leaveToSongster);
                break;
            case R.id.Car:
                Intent goToCar = new Intent(this, CarListView.class);
                startActivity(goToCar);
                message = "You clicked on item 3";
                break;
            case R.id.soccer:
                //  goToActivity = goToSoccer;
                message = getResources().getString(R.string.leaveToSoccer);
                break;
        }
        Snackbar snackbar = Snackbar
                .make(listLayout, message, Snackbar.LENGTH_LONG);
        snackbar.show();
        /*Snackbar.make(, message, BaseTransientBottomBar.LENGTH_LONG)
                .show();*/
        // startActivity(goToActivity);
        return true;
    }

    /**
     * A method that would take an item from the navigation bar
     * and makes this item clickable
     *
     * @param item
     * @return boolean
     */

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {

        int id = item.getItemId();

        /**
         * When the help item is clicked and alert dialog will
         * pop up with a title and a message
         */

        if (id == R.id.help) {
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
            alertDialogBuilder.setTitle(getResources().getString(R.string.Alert_Title))
                    .setMessage(getResources().getString(R.string.Alert_dialog))
                    .create().show();
            /**
             * When the favourites item is clicked and it will moves the user
             * to a list of the favourites were saved to the database
             * pop up with a title and a message
             */

        } else if (id == R.id.soccerFav) {
            Intent goToFavourites = new Intent(SoccerFavourite.this, SoccerFavourite.class);
//            startActivity(goToFavourites);
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
            alertDialogBuilder.setMessage("You are already in favourite page")
                    .create().show();

        } else {
//            Intent goToCarSearch = new Intent(this, CarListView.class);
//            startActivity(goToCarSearch);
            finish();
        }

        View listLayout = findViewById(R.id.activityFav_soccer);
        String message = null;
        //Look at your menu XML file. Put a case for every id in that file:
        switch (item.getItemId()) {
            //what to do when the menu item is selected:
            case R.id.trivia:
                //goToActivity = goToTrivia;
                message = getResources().getString(R.string.leaveToTrivia);
                break;
            case R.id.songster:
                // goToActivity = goToSongstar;
                message = getResources().getString(R.string.leaveToSongster);
                break;
            case R.id.Car:
                Intent goToCar = new Intent(this, CarListView.class);
                startActivity(goToCar);
                message = "You clicked on item 3";
                break;
            case R.id.soccer:
                //  goToActivity = goToSoccer;
                message = getResources().getString(R.string.leaveToSoccer);
                break;
        }

        Snackbar snackbar = Snackbar
                .make(listLayout, message, Snackbar.LENGTH_LONG);
        snackbar.show();

        DrawerLayout drawerLayout = findViewById(R.id.drawer_layout);
        drawerLayout.closeDrawer(GravityCompat.START);


        return true;
    }


    /**
     * A method gets called when the toolbar is loaded
     *
     * @param menu
     * @return boolean
     */

    public boolean onCreateOptionsMenu(Menu menu) {

        /**
         * Inflate the menu items for use in the action bar
         */

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.apptoolbar, menu);

        return true;
    }


    private class SoccerFavAdapter extends BaseAdapter {

        @Override
        public int getCount() {
            return soccerFavoriteList.size();
        }

        @Override
        public SoccerMessage getItem(int position) {
            return soccerFavoriteList.get(position);
        }

        @Override
        public long getItemId(int position) {
//            return getItem(position).getId();
            return (long) position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            //get a layout for this row at position
            LayoutInflater inflater = getLayoutInflater();
            View newView = inflater.inflate(R.layout.soccer_fav_layout, parent, false);

            // favlist title
            TextView txtTitle = newView.findViewById(R.id.soccerFavNewsTitle);
            txtTitle.setText(getItem(position).getTitle());

            // favlist date
            TextView txtDate = newView.findViewById(R.id.soccerfavNewsDate);
            txtDate.setText(getItem(position).getDate());

            // setting favlist image
            ImageView favlistThumbImge = newView.findViewById(R.id.favthumbNailImage);
            String imgUrl = getItem(position).getImgURL();
            Picasso.get().load(imgUrl).into(favlistThumbImge);

            return newView;
        }
    }


    /**
     * this method loads data from the database
     */

    private void loadFromDB() {
        // db connection:
        SoccerOpener dbOpener = new SoccerOpener(this);
        db = dbOpener.getWritableDatabase();

        // We want to get all of the columns. Look at MyOpener.java for the definitions:
        String[] columns = {SoccerOpener.SOCCER_COL_TITLE, SoccerOpener.SOCCER_COL_DATE,
                SoccerOpener.SOCCER_COL_LINK, SoccerOpener.SOCCER_COL_DESC, SoccerOpener.SOCCER_COL_IMGURL};

        //query all the results from the database:
        Cursor results = db.query(false, SoccerOpener.TABLE_NAME, columns, null, null, null, null, null, null);
        //Cursor results2 = db.rawQuery("Select * from ?", new String[]{MyOpener.TABLE_NAME});

        //Now the results object has rows of results that match the query.
        //find the column indices:
        int titleColIndex = results.getColumnIndex(SoccerOpener.SOCCER_COL_TITLE);
        int dateColIndex = results.getColumnIndex(SoccerOpener.SOCCER_COL_DATE);
        int linkColIndex = results.getColumnIndex(SoccerOpener.SOCCER_COL_LINK);
        int descIndex = results.getColumnIndex(SoccerOpener.SOCCER_COL_DESC);
        int imgURLIndex = results.getColumnIndex(SoccerOpener.SOCCER_COL_IMGURL);

        //iterate over the results, return true if there is a next item:
        while (results.moveToNext()) {
            String title = results.getString(titleColIndex);
            String date = results.getString(dateColIndex);
            String link = results.getString(linkColIndex);
            String desc = results.getString(descIndex);
            String imgURL = results.getString(imgURLIndex);

            //add the new to the array list:
            soccerFavoriteList.add(new SoccerMessage(title, date, link, desc, imgURL));
        }
    }


    /**
     * delete form database based on the title of each object
     */
    // delete from db
    private void deleteFromDB(String title) {
        db.delete(SoccerOpener.TABLE_NAME, SoccerOpener.
                SOCCER_COL_TITLE + "= ?", new String[]{title});
    }


}
