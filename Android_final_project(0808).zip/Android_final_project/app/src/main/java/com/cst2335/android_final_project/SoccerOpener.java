package com.cst2335.android_final_project;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Bitmap;

public class SoccerOpener extends SQLiteOpenHelper {
    protected final static String DATABASE_NAME = "SoccerDB";
    protected final static int VERSION_NUM = 5;
    public final static String TABLE_NAME = "SoccerTable";
    public final static String SOCCER_COL_ID = "_id";
    public final static String SOCCER_COL_TITLE = "title";
    public final static String SOCCER_COL_DATE = "date";
    public final static String SOCCER_COL_LINK = "link";
    public final static String SOCCER_COL_DESC = "desc";
    public final static String SOCCER_COL_IMGURL = "imgURL";

    public SoccerOpener(Context context) {
        super(context, DATABASE_NAME, null, VERSION_NUM);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_NAME + " (_id INTEGER PRIMARY KEY AUTOINCREMENT, "
                + SOCCER_COL_TITLE + " text,"
                + SOCCER_COL_DATE + " text,"
                + SOCCER_COL_LINK + " text,"
                + SOCCER_COL_IMGURL + " text,"
                + SOCCER_COL_DESC + " text);");

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //Drop the old table:
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);

        //Create the new table:
        onCreate(db);
    }

    @Override
    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //Drop the old table:
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);

        //Create the new table:
        onCreate(db);
    }
}
