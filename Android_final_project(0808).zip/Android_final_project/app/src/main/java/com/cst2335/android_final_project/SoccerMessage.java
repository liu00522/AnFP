package com.cst2335.android_final_project;

import android.graphics.Bitmap;

public class SoccerMessage {
    private String title;
    private String date;
    private String link;
    private Bitmap thumbImage;
    private long id;
    private String description;
    private String imgURL;

    //  cons
    public SoccerMessage(String title, String date, String link, String description, String imgURL) {
        this.id = id;
        this.title = title;
        this.date = date;
        this.link = link;
        this.description = description;
        this.imgURL = imgURL;
    }

    public SoccerMessage(int i, String title, String date, String link, Bitmap thumbNailImage, String description, String imgURL) {
        this.id = i;
        this.title = title;
        this.date = date;
        this.link = link;
        this.thumbImage = thumbNailImage;
        this.description = description;
        this.imgURL = imgURL;
    }


    //  getter & setter
    public String getTitle() {
        return title;
    }

    public String getDate() {
        return date;
    }

    public String getLink() {
        return link;
    }

    public Bitmap getThumbImage() {
        return thumbImage;
    }

    public long getId() {
        return id;
    }

    public String getImgURL() {
        return imgURL;
    }

    public String getDescription() {
        return description;
    }

    public void setImgURL(String imgURL) {
        this.imgURL = imgURL;
    }
}
