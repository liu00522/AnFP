package com.cst2335.android_final_project;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

public class EmptyActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.empty_activity);

        Bundle dataToPass = getIntent().getExtras();

        FragmentDetails newFragment = new FragmentDetails();

        newFragment.setArguments(dataToPass);

        FragmentManager fm = getSupportFragmentManager();

        fm.beginTransaction().replace(R.id.frame,newFragment).addToBackStack("AnyName").commit();


    }
}

