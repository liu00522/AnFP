package com.cst2335.android_final_project;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * AppToolbar class which inherits from AppCompatActivity
 */

public class AppToolbar extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener  {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_toolbar);

        /**
         * This gets the toolbar from the layout:
         */

        Toolbar tBar = (Toolbar)findViewById(R.id.toolbar);

        /**
         * This loads the toolbar, which calls onCreateOptionsMenu below:
         */

        setSupportActionBar(tBar);

        /**
         * this finds the DrawerLayout by id
         * and make it visible when the user
         */

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this,
                drawer, tBar, R.string.open, R.string.close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


    }

    public boolean onCreateOptionsMenu(Menu menu) {
        /**
         * Inflate the menu items for use in the action bar
         */

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.apptoolbar, menu);
        return true;
    }

    /*Intent goToTrivia = new Intent(this,TriviaActivity.class);
    Intent goToSongstar = new Intent(this,SongsterActivity.class);
    Intent goToCar = new Intent(this,CarListView.class);
    Intent goToSoccer = new Intent(this,SoccerActivity.class);
    Intent goToActivity;*/

    @Override
    public boolean onOptionsItemSelected( MenuItem item) {
        String message = null;

        switch(item.getItemId())
        {
            //what to do when the menu item is selected:
            case R.id.trivia:
                //goToActivity = goToTrivia;
                message = "You clicked on item 1";
                break;
            case R.id.songster:
               // goToActivity = goToSongstar;
                message = "You clicked on item 2";
                break;
            case R.id.Car:
               // goToActivity = goToCar;
                message = "You clicked on item 3";
                break;
            case R.id.soccer:
              //  goToActivity = goToSoccer;
                message = "You clicked on the overflow menu";
                break;
        }
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
       // startActivity(goToActivity);
        return true;
    }

    @Override
    public boolean onNavigationItemSelected( MenuItem item) {

        int id = item.getItemId();

        if (id == R.id.help ) {
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
            alertDialogBuilder.setTitle(getResources().getString( R.string.Alert_Title))
                    .setMessage(getResources().getString( R.string.Alert_dialog))
                    .create().show();
        }else if (id == R.id.favourites){
            Intent goToFavourites = new Intent(AppToolbar.this,favListView.class);
            startActivity(goToFavourites);
        }
        DrawerLayout drawerLayout = findViewById(R.id.drawer_layout);
        drawerLayout.closeDrawer(GravityCompat.START);


        return true;
    }
}