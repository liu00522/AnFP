package com.cst2335.android_final_project;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.RatingBar;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private RatingBar ratingBar;
    private Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //  soccer button
        ImageButton soccerBtn = findViewById(R.id.soccerBtn);
        //  go to soccer
        Intent soccerIntent = new Intent(MainActivity.this, SoccerActivity.class);
        soccerBtn.setOnClickListener(click -> startActivity(soccerIntent));


        //  car button
        ImageButton carBtn = findViewById(R.id.carBtn);
        //  go to car
        Intent goToCarActivity = new Intent(MainActivity.this, CarListView.class);
        carBtn.setOnClickListener(clk -> startActivity(goToCarActivity));

        // Trivia button
        ImageButton triviaBtn = findViewById(R.id.trivia);
        // go to Trivia
        Intent goToTriviaActivity = new Intent(MainActivity.this, TriviaActivity.class);
        triviaBtn.setOnClickListener(clk -> startActivity(goToTriviaActivity));



        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle("Rate my app!")
                .setMessage("Please rate my app. Thanks!")
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                Intent ratingPage = new Intent(MainActivity.this, RatingActivity.class);
                                startActivity(ratingPage);

                            }
                        }
                )
                .setNegativeButton("Not now",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                dialog.dismiss();
                                dialog.cancel();
                            }
                        }
                );
        b.show();


//        ratingBar = findViewById(R.id.rating_bar);
//        btn = findViewById(R.id.submit);
//
//        SharedPreferences prefs = getSharedPreferences("rating", Context.MODE_PRIVATE);
//        SharedPreferences.Editor edit = prefs.edit();
//
//
//        int rating = (int) prefs.getFloat("rating", 0);
//        ratingBar.setRating(rating);
//
//
//        btn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                String s = String.valueOf(ratingBar.getRating());
//                Toast.makeText(getApplicationContext(), s + "star", Toast.LENGTH_SHORT).show();
//                float rating = ratingBar.getRating();
//                edit.putFloat("rating", rating);
//
//                edit.commit();
//            }
//        });


    }
}