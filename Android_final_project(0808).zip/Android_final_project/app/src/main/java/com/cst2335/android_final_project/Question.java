package com.cst2335.android_final_project;

import java.util.ArrayList;

/**
 * Question class to hold each question's information
 */
public class Question {
    private long id;
    private String amount;
    private String difficulty;
    private String type;
    private String question;
    private String correctAnswer;
    private ArrayList<String> answers;

    /**
     * Question constructor used when create a new object of question
     * @param id incremental id
     * @param amount amount of questions
     * @param difficulty level of difficulty
     * @param type type of game
     * @param question question
     * @param correctAnswer correct answer
     * @param answers answer options
     */
    public Question(long id, String amount, String difficulty, String type, String question, String correctAnswer, ArrayList<String> answers) {
        this.id = id;
        this.amount = amount;
        this.difficulty = difficulty;
        this.type = type;
        this.question = question;
        this.correctAnswer = correctAnswer;
        this.answers = answers;
    }

    /**
     * A getter of id
     * @return returns id
     */
    public long getId() {
        return id;
    }

    /**
     * A setter of id
     * @param id id
     */
    public void setId(long id) {
        this.id = id;
    }

    /**
     * A getter of amount of questions
     * @return returns the amount of questions
     */
    public String getAmount() {
        return amount;
    }

    /**
     * A setter of amount of questions
     * @param amount the amount of questions
     */
    public void setAmount(String amount) {
        this.amount = amount;
    }

    /**
     * A getter of level of difficulty
     * @return returns the level of difficulty
     */
    public String getDifficulty() {
        return difficulty;
    }

    /**
     * A setter of the level of difficulty
     * @param difficulty level of difficulty
     */
    public void setDifficulty(String difficulty) {
        this.difficulty = difficulty;
    }

    /**
     * A getter of game type
     * @return returns the game type
     */
    public String getType() {
        return type;
    }

    /**
     * A setter of the game type
     * @param type type of game
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * A getter of question
     * @return returns question
     */
    public String getQuestion() {
        return question;
    }

    /**
     * A setter of question
     * @param question question
     */
    public void setQuestion(String question) {
        this.question = question;
    }

    /**
     * A getter of correct answer
     * @return returns the correct answer
     */
    public String getCorrectAnswer() {
        return correctAnswer;
    }

    /**
     * A setter of the correct answer
     * @param correctAnswer correct answer
     */
    public void setCorrectAnswer(String correctAnswer) {
        this.correctAnswer = correctAnswer;
    }

    /**
     * A getter of a list of all answer options
     * @return returns a list of all answer options
     */
    public ArrayList<String> getAnswers() {
        return answers;
    }

    /**
     * A setter of a list of all answer options
     * @param answers a list of all answer options
     */
    public void setAnswers(ArrayList<String> answers) {
        this.answers = answers;
    }
}
