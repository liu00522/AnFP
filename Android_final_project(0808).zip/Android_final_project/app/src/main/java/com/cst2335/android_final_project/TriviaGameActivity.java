package com.cst2335.android_final_project;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import static java.util.Collections.shuffle;

/**
 * TriviaGameActivity which is the logic of the game page of Trivia game
 * Displays question, answer options, and progression
 * Implemented toolbar and navigation bar let user to switch to other applications
 */
public class TriviaGameActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    ArrayList<Question> questions = new ArrayList<>();
    private String amount;
    private String difficulty;
    private String type;
    private static final String ACTIVITY_NAME = "GAME_ACTIVITY";
    private Question currentQuestion;
    private int questionNumber;
    private int score;
    private int wrong;
    private int numOfAnswered;
    private EditText nameField;
    private SharedPreferences prefs = null;
    private String userName;


    /**
     * onCreate is the initial stage of the class
     * Retrieves player game settings, base on that, load questions using Trivia API
     * @param savedInstanceState bundle savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        // Get intent add the game options that were selected
        Intent fromMain = getIntent();
        amount = fromMain.getStringExtra("amount");
        difficulty = fromMain.getStringExtra("difficulty");
        type = fromMain.getStringExtra("type");

        // SharedPreferences
        prefs = getSharedPreferences("UserNames", Context.MODE_PRIVATE);
        userName = prefs.getString("Name", "");


        QuestionQuery req = new QuestionQuery();
        System.out.println(" [Amount] " + amount + " [difficulty] " + difficulty + " [type] " + type);

        req.execute("https://opentdb.com/api.php?amount=" + amount + "&difficulty=" + difficulty + "&type=" + type);

        /**
         * This gets the toolbar from the layout:
         */

        androidx.appcompat.widget.Toolbar tBar = (Toolbar) findViewById(R.id.toolbar);

        /**
         * This loads the toolbar, which calls onCreateOptionsMenu below:
         */

        setSupportActionBar(tBar);

        /**
         * this finds the DrawerLayout by id
         * and make it visible when the user
         */

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this,
                drawer, tBar, R.string.open, R.string.close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    /**
     * A method gets called when the toolbar is loaded
     * @param menu
     * @return boolean
     */

    public boolean onCreateOptionsMenu(Menu menu) {

        /**
         * Inflate the menu items for use in the action bar
         */

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.apptoolbar, menu);

        return true;
    }

    /**
     * Transfer to another activity when a Toolbar option selected
     * @param item
     * @return
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        View listLayout = findViewById(R.id.activity_game);
        String message = null;
        //Look at your menu XML file. Put a case for every id in that file:
        switch (item.getItemId()) {
            //what to do when the menu item is selected:
            case R.id.trivia:
                Intent goToTrivia = new Intent(this, TriviaActivity.class);
                startActivity(goToTrivia);
                message = getResources().getString(R.string.leaveToTrivia);
                break;
            case R.id.songster:
                // goToActivity = goToSongstar;
//                message = getResources().getString(R.string.leaveToSongster);
                break;
            case R.id.Car:
                Intent goToCar = new Intent(this, CarListView.class);
                startActivity(goToCar);
                message = getResources().getString(R.string.leaveToCar);
                break;
            case R.id.soccer:
                Intent goToSoccer = new Intent(this, SoccerActivity.class);
                startActivity(goToSoccer);
                message = getResources().getString(R.string.leaveToSoccer);
                break;
        }
        Snackbar snackbar = Snackbar
                .make(listLayout, message, Snackbar.LENGTH_LONG);
        snackbar.show();

        return true;
    }

    /**
     * A method that would take an item from the navigation bar
     * and makes this item clickable
     * @param item
     * @return boolean
     */
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {

        int id = item.getItemId();

        /**
         * When the help item is clicked and alert dialog will
         * pop up with a title and a message
         */

        if (id == R.id.helpTrivia) {
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
            alertDialogBuilder.setTitle(getResources().getString(R.string.Alert_Title))
                    .setMessage(getResources().getString(R.string.Alert_dialog_trivia))
                    .create().show();
            /**
             * When the favourites item is clicked and it will moves the user
             * to a list of the favourites were saved to the database
             * pop up with a title and a message
             */

        } else if (id == R.id.seeScore) {
            Intent goToScore = new Intent(TriviaGameActivity.this, TriviaScoreActivity.class);
            startActivity(goToScore);

            /**
             * When the finish item is clicked the navigation bar will close
             * and go back to the car search activity
             *
             */

        } else if (id == R.id.finish) {
            Intent goToTrivia = new Intent(this, TriviaActivity.class);
            startActivity(goToTrivia);
            finish();
        }

        View listLayout = findViewById(R.id.activity_game);
        String message = null;
        //Look at your menu XML file. Put a case for every id in that file:
        switch (item.getItemId()) {
            //what to do when the menu item is selected:
            case R.id.trivia:
                Intent goToTrivia = new Intent(this, TriviaActivity.class);
                startActivity(goToTrivia);
                message = getResources().getString(R.string.leaveToTrivia);
                break;
            case R.id.songster:
                // goToActivity = goToSongstar;
//                message = getResources().getString(R.string.leaveToSongster);
                break;
            case R.id.Car:
                Intent goToCar = new Intent(this, CarListView.class);
                startActivity(goToCar);
                message = getResources().getString(R.string.leaveToCar);
                break;
            case R.id.soccer:
                Intent goToSoccer = new Intent(this, SoccerActivity.class);
                startActivity(goToSoccer);
                message = getResources().getString(R.string.leaveToSoccer);
                break;
        }

        Snackbar snackbar = Snackbar
                .make(listLayout, message, Snackbar.LENGTH_LONG);
        snackbar.show();

        DrawerLayout drawerLayout = findViewById(R.id.drawer_layout);
        drawerLayout.closeDrawer(GravityCompat.START);

        return true;
    }


    /**
     * QuestionQuery class which inherits from AsyncTask
     * Asynchronous work, fetching data from Trivia API in background and save it in Question List
     *
     */
    class QuestionQuery extends AsyncTask<String, Integer, String> {

        String question;
        String correct;

        /**
         * It fetches data from Trivia API in background and saves it in Question List
         * @param args arguments
         * @return returns "Done", calls onPostExecute method
         */
        @Override
        protected String doInBackground(String... args) {

            try {
                //create a URL object of what server to contact:
                URL url = new URL(args[0]);
                //open the connection
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
                //wait for data:
                InputStream response = urlConnection.getInputStream();

                //Build the entire string response:
                BufferedReader reader = new BufferedReader(new InputStreamReader(response, "UTF-8"), 8);
                StringBuilder sb = new StringBuilder();

                String line = null;
                while ((line = reader.readLine()) != null)
                {
                    sb.append(line + "\n");
                }
                String result = sb.toString();

                // convert string to JSON: Look at slide 27:
                JSONObject triviaResult = new JSONObject(result);

                JSONArray jArray = triviaResult.getJSONArray("results");

                for (int i = 0; i < jArray.length(); i++) {
                    JSONObject obj = jArray.getJSONObject(i);
                    question = obj.getString("question");
                    correct = obj.getString("correct_answer");

                    ArrayList<String> answers = new ArrayList<>();
                    JSONArray incorrectAnswers = obj.getJSONArray("incorrect_answers");
                    for (int j = 0; j < incorrectAnswers.length(); j++) {
                        answers.add(incorrectAnswers.getString(j));
                    }
                    answers.add(correct);
                    shuffle(answers);

                    // create question object and add to arrayList
                    // id, amount, difficulty, type, question, correct, answers
                    Question newQ = new Question(i+1, amount, difficulty, type, question, correct, answers);
                    questions.add(newQ);
                }
            }
            catch (Exception e) {
                e.printStackTrace();
            }
            return "Done";
        }

        /**
         * It updates the progressbar
         * @param value
         */
        public void onProgressUpdate(Integer ... value)
        {
            // this function is not necessary to run the program
            // call this in response to publishProgress();
            ProgressBar progressBar = findViewById(R.id.progressBar);
            progressBar.setProgressTintList(ColorStateList.valueOf(Color.DKGRAY));
            progressBar.setProgress(value[0]);
            Log.i("HTTP", "In onProgressUpdate");
        }

        /**
         * It is called after async task is done.
         * @param fromDoInBackground fromDoInBackground
         */
        public void onPostExecute(String fromDoInBackground)    // fromDoInBackground = "Done"
        {   // all messages have arrived on main processor, doInBackground is finished

            nextQuestion(questionNumber);
        }

        /**
         * Actions when there is next question or not
         * Show game result and name field for player to enter after all questions are answered
         * Show next question if not done yet.
         * @param idx index of questions
         */
        private void nextQuestion(int idx) {
            // When all questions are answered
            if (idx >= Integer.parseInt(amount)) {
                publishProgress(100);
                Button answer1 = findViewById(R.id.ans1);
                Button answer2 = findViewById(R.id.ans2);
                Button answer3 = findViewById(R.id.ans3);
                Button answer4 = findViewById(R.id.ans4);
                nameField = findViewById(R.id.nameField);
                Button seeScore = findViewById(R.id.seeScore);
                TextView yourScore = findViewById(R.id.yourScore);
                TextView finalScore = findViewById(R.id.finalScore);
                TextView unanswered = findViewById(R.id.notYetAnswered);
                TextView wronglyAnswered = findViewById(R.id.answeredWrong);
                TextView correctlyAnswered = findViewById(R.id.answeredRight);

                unanswered.setText(String.valueOf(Integer.parseInt(amount) - numOfAnswered));
                wronglyAnswered.setText(String.valueOf(wrong));
                correctlyAnswered.setText(String.valueOf(score));
                answer1.setVisibility(View.INVISIBLE);
                answer2.setVisibility(View.INVISIBLE);
                answer3.setVisibility(View.INVISIBLE);
                answer4.setVisibility(View.INVISIBLE);
                nameField.setVisibility(View.VISIBLE);
                seeScore.setVisibility(View.VISIBLE);
                yourScore.setVisibility(View.VISIBLE);
                finalScore.setVisibility(View.VISIBLE);

                nameField.setText(userName);

                // Show the final score
                finalScore.setText(String.valueOf(score * (100 / Integer.parseInt(amount))));
                // call goToScorePage() when button is clicked
                seeScore.setOnClickListener(click -> {
                    saveSharedPrefs();
                    goToScorePage();
                });

            // update progressbar and update question with the next question
            } else {
                publishProgress((idx * (100 / Integer.parseInt(amount))));
                // Get next question
                currentQuestion = questions.get(idx);
                // update the TextViews that are dependent on the question
                updateQuestion();
            }
        }

        /**
         * It directs to the score page
         */
        private void goToScorePage() {
            // Go to score page
            Intent goToScorePage = new Intent(TriviaGameActivity.this, TriviaScoreActivity.class);
            goToScorePage.putExtra("Name", nameField.getText().toString());
            goToScorePage.putExtra("Difficulty", difficulty);
            goToScorePage.putExtra("Score", String.valueOf(score * (100 / Integer.parseInt(amount))));
            goToScorePage.putExtra("Amount", amount);
            goToScorePage.putExtra("Type", type);

            startActivity(goToScorePage);
        }

        /**
         * Update new question based on the game setting and the index of questions
         */
        private void updateQuestion() {
            TextView ques = findViewById(R.id.question);
            TextView unanswered = findViewById(R.id.notYetAnswered);
            TextView wronglyAnswered = findViewById(R.id.answeredWrong);
            TextView correctlyAnswered = findViewById(R.id.answeredRight);

            ques.setText(currentQuestion.getQuestion());
            unanswered.setText(String.valueOf(Integer.parseInt(amount) - numOfAnswered));
            wronglyAnswered.setText(String.valueOf(wrong));
            correctlyAnswered.setText(String.valueOf(score));

            Button answer1 = findViewById(R.id.ans1);
            Button answer2 = findViewById(R.id.ans2);
            Button answer3 = findViewById(R.id.ans3);
            Button answer4 = findViewById(R.id.ans4);

            if (currentQuestion.getType().equals("boolean")) {
                // True and False
                answer1.setText("True");
                answer2.setText("False");
                // Set only two buttons visible for True and False
                answer1.setVisibility(View.VISIBLE);
                answer2.setVisibility(View.VISIBLE);
            } else {
                // Set all the buttons back to visible for Multiple Choices
                answer1.setVisibility(View.VISIBLE);
                answer2.setVisibility(View.VISIBLE);
                answer3.setVisibility(View.VISIBLE);
                answer4.setVisibility(View.VISIBLE);

                // Set answer options on each button
                answer1.setText(currentQuestion.getAnswers().get(0));
                answer2.setText(currentQuestion.getAnswers().get(1));
                answer3.setText(currentQuestion.getAnswers().get(2));
                answer4.setText(currentQuestion.getAnswers().get(3));
            }

            selectAnswer();
        }


        /**
         * Shows answer options;
         * Two for true or false questions
         * Four for multiple questions
         */
        private void selectAnswer() {
            Button answer1 = findViewById(R.id.ans1);
            Button answer2 = findViewById(R.id.ans2);
            Button answer3 = findViewById(R.id.ans3);
            Button answer4 = findViewById(R.id.ans4);

            answer1.setOnClickListener(click -> {
                String userAnswer = answer1.getText().toString();

                if (userAnswer.equals(currentQuestion.getCorrectAnswer())) {
                    score++;
                    Toast.makeText(getApplicationContext(), "Correct!", Toast.LENGTH_LONG).show();
                    System.out.println("[Correct] Score: " + score);
                } else {
                    wrong++;
                    System.out.println("[Incorrect] Number of Incorrect: " + wrong);
                }

                questionNumber++;
                numOfAnswered++;
                nextQuestion(questionNumber);
            });

            answer2.setOnClickListener(click -> {
                String userAnswer = answer2.getText().toString();

                if (userAnswer.equals(currentQuestion.getCorrectAnswer())) {
                    score++;
                    Toast.makeText(getApplicationContext(), "Correct!", Toast.LENGTH_LONG).show();
                    System.out.println("[Correct] Score: " + score);
                } else {
                    wrong++;
                    System.out.println("[Incorrect] Number of Incorrect: " + wrong);
                }

                questionNumber++;
                numOfAnswered++;
                nextQuestion(questionNumber);
            });

            answer3.setOnClickListener(click -> {
                String userAnswer = answer3.getText().toString();

                if (userAnswer.equals(currentQuestion.getCorrectAnswer())) {
                    score++;
                    Toast.makeText(getApplicationContext(), "Correct!", Toast.LENGTH_LONG).show();
                    System.out.println("[Correct] Score: " + score);
                } else {
                    wrong++;
                    System.out.println("[Incorrect] Number of Incorrect: " + wrong);
                }

                questionNumber++;
                numOfAnswered++;
                nextQuestion(questionNumber);
            });

            answer4.setOnClickListener(click -> {
                String userAnswer = answer4.getText().toString();

                if (userAnswer.equals(currentQuestion.getCorrectAnswer())) {
                    score++;
                    Toast.makeText(getApplicationContext(), "Correct!", Toast.LENGTH_LONG).show();
                    System.out.println("[Correct] Score: " + score);
                } else {
                    wrong++;
                    System.out.println("[Incorrect] Number of Incorrect: " + wrong);
                }

                questionNumber++;
                numOfAnswered++;
                nextQuestion(questionNumber);
            });
        }
    }

    /**
     * It saves the sharedPreferences, player name
     */
    protected void saveSharedPrefs() {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("Name", nameField.getText().toString());
        editor.commit();
    }
}