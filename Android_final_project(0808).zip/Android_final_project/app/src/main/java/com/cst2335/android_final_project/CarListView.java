package com.cst2335.android_final_project;

import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Message;
import android.text.Layout;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;

import org.w3c.dom.Text;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

/**
 * A public class that inherits from AppCompatActivity super class
 * and it includes AsyncTask class, baseAdapter class
 */
public class CarListView extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    /**
     * Variables declared to be used throughout the CarListView class
     */

    public static CarListAdapter myAdapter;
    public static ArrayList<Car> carList = new ArrayList<>();
    public SQLiteDatabase db;
    public static String ITEM_POSITION;
    public static ProgressBar progressBar;
    public static Button getCars;
    private SharedPreferences prefs = null;
    public static Car carResults;

    /**
     * An onCreate function which gets called when the program starts
     *
     * @param savedInstanceState
     */

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        /**
         * finding the layout that will be sued for the CarListView class2
         */
        setContentView(R.layout.list_layout);

        /**
         * finding the widgets that were added to the layout by id
         */


        EditText carSearch = findViewById(R.id.carSearch);
        getCars = findViewById(R.id.search);
        progressBar = findViewById(R.id.progressBar);
        progressBar.setVisibility(View.INVISIBLE);
        ListView carView = findViewById(R.id.carList);


        CarDataBase dbHelper = new CarDataBase(this);
        db = dbHelper.getWritableDatabase();

        /**
         * Creating an Adapter object
         * and is being set to be used by the car list
         */

        myAdapter = new CarListAdapter();
        carView.setAdapter(myAdapter);

        /**
         * Creating a SQlite object to create a data base to add
         * favourite cars and remove  from it
         */

        CarDataBase dbOpener = new CarDataBase(this);
        db = dbOpener.getWritableDatabase();


        /**
         * Using a Shared preference to save the last make
         * the user entered to search for
         */

        prefs = getSharedPreferences("lastSearch", Context.MODE_PRIVATE);
        String carSearched = prefs.getString("CarMake", "");
        carSearch.setText(carSearched);


        CarSearchResults reqCar = new CarSearchResults();

        boolean isTablet = findViewById(R.id.frame) != null;

        /**
         * When the search button is clicked
         * the make would be saved to the shared references
         * and execute function would call doInBackground function
         * to search for the cars from the server
         */


        getCars.setOnClickListener(s -> {

            saveSharedPrefs(carSearch.getText().toString());

            reqCar.execute("https://vpic.nhtsa.dot.gov/api/vehicles/GetModelsForMake/" + carSearch.getText().toString() + "?format=XML");

            Toast.makeText(this, getResources().getString(R.string.instructions), Toast.LENGTH_LONG).show();
        });

        /**
         * When clicking on a car in list it will show the name of the car in fragment
         * and create a bundle to send the data of this car to the fragment
         *
         */


        carView.setOnItemClickListener((list, item, position, id) -> {

            Bundle dataToPass = new Bundle();

            dataToPass.putLong(CarDataBase.COL_ID, position);
            dataToPass.putString(CarDataBase.COL_MAKE_ID, carList.get(position).getMakeID());
            dataToPass.putString(CarDataBase.COL_MAKE_NAME, carList.get(position).getCarMake());
            dataToPass.putString(CarDataBase.COL_MODEL_NAME, carList.get(position).getCarName());
            dataToPass.putString(CarDataBase.COL_MODEL_ID, carList.get(position).getNameID());
            dataToPass.putInt(ITEM_POSITION, position);


            /**
             * An if condition to decide is it a tablet or a phone for the fragment
             */

            if (isTablet) {
                FragmentDetails dFragment = new FragmentDetails(); //add a DetailFragment
                dFragment.setArguments(dataToPass); //pass it a bundle for information
                getSupportFragmentManager()
                        .beginTransaction()
                        .replace(R.id.frame, dFragment) //Add the fragment in FrameLayout
                        .commit(); //actually load the fragment. Calls onCreate() in DetailFragment
            } else //isPhone
            {
                Intent nextActivity = new Intent(CarListView.this, EmptyActivity.class);
                nextActivity.putExtras(dataToPass); //send data to next activity
                startActivity(nextActivity); //make the transition
            }
        });


        /**
         * This gets the toolbar from the layout:
         */

        androidx.appcompat.widget.Toolbar tBar = (Toolbar) findViewById(R.id.toolbar);

        /**
         * This loads the toolbar, which calls onCreateOptionsMenu below:
         */

        setSupportActionBar(tBar);

        /**
         * this finds the DrawerLayout by id
         * and make it visible when the user
         */

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this,
                drawer, tBar, R.string.open, R.string.close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


    }

    /**
     * A method gets called when the toolbar is loaded
     *
     * @param menu
     * @return boolean
     */

    public boolean onCreateOptionsMenu(Menu menu) {

        /**
         * Inflate the menu items for use in the action bar
         */

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.apptoolbar, menu);

        return true;
    }



    /*Intent goToTrivia = new Intent(this,TriviaActivity.class);
    Intent goToSongstar = new Intent(this,SongsterActivity.class);
    Intent goToCar = new Intent(this,CarListView.class);
    Intent goToSoccer = new Intent(this,SoccerActivity.class);
    Intent goToActivity;*/

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        View listLayout = findViewById(R.id.listLayout);
        String message = null;
        //Look at your menu XML file. Put a case for every id in that file:
        switch (item.getItemId()) {
            //what to do when the menu item is selected:
            case R.id.trivia:
                //goToActivity = goToTrivia;
                message = getResources().getString(R.string.leaveToTrivia);
                break;
            case R.id.songster:
                // goToActivity = goToSongstar;
                message = getResources().getString(R.string.leaveToSongster);
                break;
            case R.id.Car:
                // goToActivity = goToCar;
                message = getResources().getString(R.string.leaveToCar);
                break;
            case R.id.soccer:
                Intent goToSoccer = new Intent(this, SoccerActivity.class);
                startActivity(goToSoccer);
                message = getResources().getString(R.string.leaveToSoccer);
                break;
        }
        Snackbar snackbar = Snackbar
                .make(listLayout, message, Snackbar.LENGTH_LONG);
        snackbar.show();
        /*Snackbar.make(, message, BaseTransientBottomBar.LENGTH_LONG)
                .show();*/
        // startActivity(goToActivity);
        return true;
    }

    /**
     * A method that would take an item from the navigation bar
     * and makes this item clickable
     *
     * @param item
     * @return boolean
     */

    @Override
    public boolean onNavigationItemSelected(MenuItem item) {

        int id = item.getItemId();

        /**
         * When the help item is clicked and alert dialog will
         * pop up with a title and a message
         */

        if (id == R.id.help) {
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
            alertDialogBuilder.setTitle(getResources().getString(R.string.Alert_Title))
                    .setMessage(getResources().getString(R.string.Alert_dialog))
                    .create().show();
            /**
             * When the favourites item is clicked and it will moves the user
             * to a list of the favourites were saved to the database
             * pop up with a title and a message
             */

        } else if (id == R.id.favourites) {
            Intent goToFavourites = new Intent(CarListView.this, favListView.class);
            startActivity(goToFavourites);

            /**
             * When the finish item is clicked the navigation bar will close
             * and go back to the car search activity
             *
             */

        } else if (id == R.id.finish) {
            Intent goToCarSearch = new Intent(this, CarListView.class);
            startActivity(goToCarSearch);
            finish();
        }

        View listLayout = findViewById(R.id.listLayout);
        String message = null;
        //Look at your menu XML file. Put a case for every id in that file:
        switch (item.getItemId()) {
            //what to do when the menu item is selected:
            case R.id.trivia:
                //goToActivity = goToTrivia;
                message = getResources().getString(R.string.leaveToTrivia);
                break;
            case R.id.songster:
                // goToActivity = goToSongstar;
                message = getResources().getString(R.string.leaveToSongster);
                break;
            case R.id.Car:
                // goToActivity = goToCar;
                message = getResources().getString(R.string.leaveToCar);;
                break;
            case R.id.soccer:
                Intent goToSoccer = new Intent(this, SoccerActivity.class);
                startActivity(goToSoccer);
                message = getResources().getString(R.string.leaveToSoccer);
                break;
        }

        Snackbar snackbar = Snackbar
                .make(listLayout, message, Snackbar.LENGTH_LONG);
        snackbar.show();

        DrawerLayout drawerLayout = findViewById(R.id.drawer_layout);
        drawerLayout.closeDrawer(GravityCompat.START);


        return true;
    }

    /**
     * A save Shared preferences method that would take
     * the text the user entered in the search and save in a Map
     *
     * @param stringToSave
     */

    private void saveSharedPrefs(String stringToSave) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("CarMake", stringToSave);
        editor.commit();
    }

    /**
     * A saveCar method that would use the id of the car
     * and add it to a database so the user can directly see the cars
     * that he prefer and a toast message would appear after the care is successfully added
     * to the database
     *
     * @param id
     */


    public void saveCar(int id) {

        Car addFav = carList.get(id);
        ContentValues newRowValues = new ContentValues();
        newRowValues.put(CarDataBase.COL_MAKE_ID, addFav.getMakeID());
        newRowValues.put(CarDataBase.COL_MAKE_NAME, addFav.getCarMake());
        newRowValues.put(CarDataBase.COL_MODEL_NAME, addFav.getCarName());
        newRowValues.put(CarDataBase.COL_MODEL_ID, addFav.getNameID());
        long dbID = db.insert(CarDataBase.TABLE_NAME, null, newRowValues);

        if (dbID > 0) {
            Toast.makeText(this, getResources().getString(R.string.saveDone), Toast.LENGTH_LONG).show();
        }
    }

    /**
     * A CarListAdapter class which inherits from the BaseAdapter super class
     * that class implements four methods
     * getCount, getItem, getItemId,getView
     */

    class CarListAdapter extends BaseAdapter {

        /**
         * A getCount methods which return the size of the list
         *
         * @return
         */


        @Override
        public int getCount() {
            return carList.size();
        }

        /**
         * A getItem method which returns a number
         * that represents the position of the item that was clicked
         *
         * @param position
         * @return the position of the item o the list
         */

        @Override
        public Car getItem(int position) {
            return carList.get(position);
        }

        /**
         * A getItemId method which returns the database id
         * of the selected item on the list
         *
         * @param dbID
         * @return returns long which represent the database id
         * of the selected item on the list
         */

        @Override
        public long getItemId(int dbID) {
            return dbID;
        }

        /**
         * A getView method which makes the rows in the list customizable
         *
         * @param position
         * @param convertView
         * @param viewGroup
         * @return
         */

        @Override
        public View getView(int position, View convertView, ViewGroup viewGroup) {

            LayoutInflater inflater = getLayoutInflater();
            View carModelRow = inflater.inflate(R.layout.row_view, viewGroup, false);

            TextView carModelName = carModelRow.findViewById(R.id.carModelName);
            carModelName.setText(getResources().getString(R.string.rowCarModel) + getItem(position).getCarName());

            TextView carModelID = carModelRow.findViewById(R.id.carModelID);
            carModelID.setText(getResources().getString(R.string.rowCarID) + getItem(position).getNameID());

            return carModelRow;
        }
    }

    /**
     * CarSearchResult class which extends AsyncTask
     * which will execute the long tasks on a different thread
     */


    static class CarSearchResults extends AsyncTask<String, Integer, String> {

        String makeID;
        String makeName;
        String modelID;
        String carModel;

        /**
         * doInBackground is a method to perform the tasks
         * that would take too much time to be completed on
         * another thread.Such as connecting to a server to download
         * data as here.
         *
         * @param args
         * @return String
         */


        @Override
        protected String doInBackground(String... args) {

            try {

                //String URL = URLEncoder.encode(String, "UTF-8");

                //create a URL object of what server to contact:
                URL url = new URL(args[0]);

                //open the connection
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

                //wait for data:
                InputStream response = urlConnection.getInputStream();

                XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
                factory.setNamespaceAware(false);
                XmlPullParser xpp = factory.newPullParser();
                xpp.setInput(response, "UTF-8");

                int eventType = xpp.getEventType();

                /**
                 * looping through the XML tags to extract the data we want from the server
                 */

                // looping through the xml file to get the required data

                while (eventType != XmlPullParser.END_DOCUMENT) {

                    if (eventType == XmlPullParser.START_TAG) {
                        //If you get here, then you are pointing at a start tag
                        if (xpp.getName().equals("Make_ID")) {
                            xpp.next();
                            makeID = xpp.getText();
                            publishProgress(25);
                            xpp.next();

                        }

                        if (xpp.getName().equals("Make_Name")) {
                            xpp.next();
                            makeName = xpp.getText();
                            publishProgress(50);
                            xpp.next();

                        }

                        if (xpp.getName().equals("Model_ID")) {
                            xpp.next();
                            modelID = xpp.getText();
                            publishProgress(75);
                            xpp.next();

                        }

                        if (xpp.getName().equals("Model_Name")) {
                            xpp.next();
                            carModel = xpp.getText();
                            publishProgress(95);
                            xpp.next();
                            carResults = new Car(makeID, makeName, carModel, modelID);
                            carList.add(carResults);

                        }
                    }
                    eventType = xpp.next(); //move to the next xml event and store it in a variable
                }
                publishProgress(100);
            } catch (XmlPullParserException xmlPullParserException) {
                xmlPullParserException.printStackTrace();
            } catch (UnsupportedEncodingException unsupportedEncodingException) {
                unsupportedEncodingException.printStackTrace();
            } catch (MalformedURLException malformedURLException) {
                malformedURLException.printStackTrace();
            } catch (IOException ioException) {
                ioException.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
            return "Done";
        }

        /**
         * onProgressUpdate is a method to update the GUI
         * based on the results are sent by the doInBackground method
         * like here I am showing a progress bar while the search results
         * is being downloaded to the list.
         *
         * @param values
         */

        @Override
        protected void onProgressUpdate(Integer... values) {
            super.onProgressUpdate(values);
            progressBar.setVisibility(View.VISIBLE);
            progressBar.setProgress(values[0]);

        }

        /**
         * onPostExecute method is invoked after
         * doInBackground is done and the GUI need the final update
         *
         * @param sentFromDoInBackground
         */


        @Override
        protected void onPostExecute(String sentFromDoInBackground) {
            super.onPostExecute(sentFromDoInBackground);
            progressBar.setVisibility(View.INVISIBLE);
            myAdapter.notifyDataSetChanged();
        }
    }

}

/*info.setOnClickListener(c ->{
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
            alertDialogBuilder.setTitle(getResources().getString( R.string.Alert_Title))
            .setMessage(getResources().getString( R.string.Alert_dialog))
            .create().show();
        });

        /**
         * A snack bar to show to help the user how
         * to interact with the app
         */

// A snack bar with a help button that will call an alert dialog

        /*Snackbar.make(info, "Click on help for more info!", BaseTransientBottomBar.LENGTH_LONG)
        .setAction("Help!", click ->{
            AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
            alertDialogBuilder.setTitle("Click on the car name to its info appear!");
        } ).show();

        Intent goToToolbar = new Intent(this,AppToolbar.class);

        /**
         * When click on favourites button
         * it will transition to favListView activity using an intent
         */

/*Button saveToDB = carModelRow.findViewById(R.id.save);

            saveToDB.setOnClickListener(s ->{

                ContentValues newRowValues = new ContentValues();
                newRowValues.put(CarDataBase.COL_MAKE_ID, carList.get(position).getMakeID());
                newRowValues.put(CarDataBase.COL_MAKE_NAME, carList.get(position).getCarMake());
                newRowValues.put(CarDataBase.COL_MODEL_NAME, carList.get(position).getCarName());
                newRowValues.put(CarDataBase.COL_MODEL_ID, carList.get(position).getNameID());
                long dbID = db.insert(CarDataBase.TABLE_NAME,null,newRowValues);

            if(dbID > 0 ){
                Toast.makeText(getBaseContext(), getResources().getString( R.string.saveDone) , Toast.LENGTH_LONG).show();
            }
            });*/