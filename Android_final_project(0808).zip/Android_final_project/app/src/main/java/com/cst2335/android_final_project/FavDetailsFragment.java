package com.cst2335.android_final_project;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

/**
 * A FavDetailsFragment that inherits from Fragment interface
 *
 */

public class FavDetailsFragment extends Fragment {

    /**
     * declaring variables
     *
     */
    private long id;
    private int position;
    private String carMake;
    private String makeID;
    private String carName;
    private String nameID;
    AppCompatActivity parentActivity;
    public SQLiteDatabase db ;

    /**
     * onCreateView method to inflate the UI
     * @param inflater
     * @param container
     * @param savedInstanceState
     * @return the inflated view
     */

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        /**
         * getting that data from the previous activity
         */

        Bundle dataFromActivity = getArguments();

        id = dataFromActivity.getLong(CarDataBase.COL_ID);
        makeID = dataFromActivity.getString(CarDataBase.COL_MAKE_ID);
        carMake = dataFromActivity.getString(CarDataBase.COL_MAKE_NAME);
        carName = dataFromActivity.getString(CarDataBase.COL_MODEL_NAME);
        nameID = dataFromActivity.getString(CarDataBase.COL_MODEL_ID);
        position = dataFromActivity.getInt(CarListView.ITEM_POSITION);

        View fragmentView = inflater.inflate(R.layout.fragment_fav_details, container, false);

        TextView modelName = fragmentView.findViewById(R.id.carSaved);
        modelName.setText(getResources().getString( R.string.favNameFrg)+ carName);

        /**
         * finding the buttons by the id in the fragment
         */


        Button delete = fragmentView.findViewById(R.id.carDel);
        Button shop = fragmentView.findViewById(R.id.carShop);
        Button details = fragmentView.findViewById(R.id.carDetails);

        /**
         *Creating a url string and intent for shopping the desired car
         */

        String shopURL = "http://www.google.com/search?q="+ carMake + "+" + carName;
        Intent showOffers = new Intent(Intent.ACTION_VIEW);
        showOffers.setData( Uri.parse(shopURL) );

        /**
         *Creating a url string and intent to show more details about the desired car
         */

        String detailsURL = "https://www.autotrader.ca/cars/?mdl="+ carName +"&make="+ carMake +"&loc=K2G1V8";
        Intent showDetails = new Intent(Intent.ACTION_VIEW);
        showDetails.setData( Uri.parse(detailsURL) );

        CarDataBase dbHelper = new CarDataBase(parentActivity);
        db = dbHelper.getWritableDatabase();

        /**
         * A delete button when clicked will trigger an event listener
         * that will delete the unwanted car from the database
         * and update the list and the database by doing so
         */

        delete.setOnClickListener( s -> {

            ContentValues newRowValues = new ContentValues();
            newRowValues.put(CarDataBase.COL_MAKE_ID, makeID);
            newRowValues.put(CarDataBase.COL_MAKE_NAME, carMake);
            newRowValues.put(CarDataBase.COL_MODEL_NAME, carName);
            newRowValues.put(CarDataBase.COL_MODEL_ID, nameID);
            db.delete(CarDataBase.TABLE_NAME, CarDataBase.COL_ID + "= " + id,null);
            Toast.makeText(parentActivity, getResources().getString( R.string.carDeleted ) , Toast.LENGTH_LONG).show();

        });

        /**
         * A shop button when clicked will trigger an event listener
         * that will direct the user to ana external website
         * where he can see the current prices of the car he wants
         */

        shop.setOnClickListener(c -> startActivity(showOffers));

        /**
         * A details button when clicked will trigger an event listener
         * that will direct the user to ana external website
         * where he can see the more details of the car he wants
         */

        details.setOnClickListener( click -> startActivity(showDetails));


        return fragmentView;
    }
    public void onAttach(Context context) {
        super.onAttach(context);

        //context will either be FragmentExample for a tablet, or EmptyActivity for phone
        parentActivity = (AppCompatActivity)context;
    }
}